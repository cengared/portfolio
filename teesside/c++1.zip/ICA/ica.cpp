// CP1 ICA - Processing Student Data
// Daniel Stokoe - W0093152

// Pre-processor statements

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cctype>
using namespace std;


// Class definition

class Student{
	public:
		Student(string, string, int, int, int);
		Student();
		int getYear() {return year;}
		double calcOverallMark();
		double getOverallMark() {return overallMark;}
		string formatName();
		bool passed();
        string getForename() {return forename;}
        string getSurname() {return surname;}
        static int studentCount;
        static int passCount;
        static int failCount;

	private:
        string forename;
        string surname;
   		int year;
		int mark1;
		int mark2;
		double overallMark;
};

int Student::studentCount = 0;
int Student::passCount = 0;
int Student::failCount =0;

Student::Student(string fn, string sn, int y, int m1, int m2)
{
    forename = fn;
    surname = sn;
	year = y;
	mark1 = m1;
	mark2 = m2;
	studentCount++;
}

Student::Student()
{
    forename = "Default";
    surname = "Name";
    year = 1;
    mark1 = 0;
    mark2 = 0;
}


// Function prototypes

void openFiles(ifstream & infile, ofstream & outfileP, ofstream & outfileF);

void menu(char & ch);


// Main function

int main()
{
	string firstName, secondName, fullName;
	int sYear, sMark1, sMark2;
   	char choice = ' ';
	ifstream dataFile;
	ofstream passFile, failFile;
	string highName, lowName;
	double highMark = 0, lowMark = 100;

	menu(choice);
	openFiles(dataFile, passFile, failFile);

	while (dataFile >> firstName >> secondName >> sYear >> sMark1 >> sMark2)
	{
        Student student(firstName, secondName, sYear, sMark1, sMark2);

        fullName = student.formatName();
       
		student.calcOverallMark();

		if (student.passed())
		{
			passFile << fullName << "\t" << student.getOverallMark();
			passFile << "%\tPASS" << endl;
		}
		else
		{
			failFile << fullName << "\t" << student.getOverallMark();
			failFile << "%\tFAIL" << endl;
		}

		if (student.getOverallMark() > highMark)
		{
			highMark = student.getOverallMark();
			highName = fullName;
		}

        if (student.getOverallMark() < lowMark)
		{
			lowMark = student.getOverallMark();
			lowName = fullName;
		}

	}

	if (choice == 'H')
	{
		cout << "The student with the highest ";
		cout <<"overall mark was " << highName;
		cout << " with " << highMark << "%." << endl;
	}
	else
	{
		cout << "The student with the lowest ";
		cout << "overall mark was " << lowName;
		cout << " with " << lowMark << "%." << endl;
	}

   	cout << "Total number of passes: " << Student::passCount << endl;
	cout << "Total number of fails: " << Student::failCount << endl;

	return 0;
}


// Class member functions

double Student::calcOverallMark()
{
	if (year == 1)
	{
		overallMark = (mark1 * 0.5) + (mark2 * 0.5);
	}
	else if (year == 2)
	{
		overallMark = (mark1 * 0.4) + (mark2 * 0.6);
	}
	else
	{
		overallMark = (mark1 * 0.3) + (mark2 * 0.7);
	}

	return overallMark;
}

string Student::formatName()
{
	char initial;
	string finalName;

	initial = forename[0];
	finalName = surname + ", " + initial + ".";
	return finalName;
}

bool Student::passed()
{
	if (overallMark >= 40)
    {
        passCount++;
        return true;
    }

	else
    {
        failCount++;
		return false;
    }

}


// Function definitions

void openFiles(ifstream & infile, ofstream & outfileP, ofstream & outfileF)
{
	infile.open("data.txt");
	if (infile.fail())
	{
		cout << "Error opening file." << endl;
		exit (1);
	}

	outfileP.open("pass.txt");
	if (outfileP.fail())
	{
		cout << "Error opening file." << endl;
		exit (1);
	}

	outfileF.open("fail.txt");
	if (outfileF.fail())
	{
		cout << "Error opening file." << endl;
		exit (1);
	}

	return;
}

void menu(char & ch)
{
	cout << "Welcome to the Student Assement Processing ";
	cout << "Program!" << endl;
	cout << "\nWhich student would you like to see at ";
	cout << "the end of the program?" << endl;
	cout << "To view the student with the highest ";
	cout << "overall mark, please enter H." << endl;
	cout << "Or to view the student with the lowest ";
	cout << "overall mark, please enter L." << endl;
	cout << "Please enter your choice now:" << endl;
	cin >> ch;

	ch = toupper(ch);

	while (ch != 'H' && ch != 'L')
	{
		cout << "\nInvalid selection." << endl;
		cout << "Please enter H, for highest, or L, ";
		cout << "for lowest overall mark." << endl;
		cout << "Try again now:" << endl;
		cin >> ch;
		ch = toupper(ch);
	}

	return;
}

