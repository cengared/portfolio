// Daniel Stokoe, W0093152
// CP2, ICA, Beggar class member functions

#include <iostream>
#include <string>
using namespace std;
#include "player.h"
#include "beggar.h"
#include "point.h"

Beggar::Beggar(string n, string aff): Player(n)
{
	affliction = aff;
}

//function used to move Beggar players
void Beggar::move()
{
	int moveX, moveY;
	char key;
	
    moveX = (rand()%100)-50;
	moveY = (rand()%100)-50;
	
	cout << "\n" << name << " is moving " << moveX << " units in the X direction" << endl;
	cout << "and " << moveY << " units in the Y direction." << endl;
	
	cout << "\nPress any key & enter to continue on the next player." << endl;
	cin >> key;
	cout << "\n";
	
	//sends the user inputted data to the Point class
	//to change the player's current position
	position.adjust(moveX, moveY);
	
	return;
}

//function used to award points to Beggar players
void Beggar::evaluate(Point *t[], int s)
{
	//loop to go through entire array of treasure location points
	for (int i = 0; i < s; i++)
	{
		//distance to treasure determines number of points given
		if (position - *t[i] <= 5)
		{
			score += 10;
		}
		
	}
	
	return;
}

//function used to print the details of Beggar players
void Beggar::printDetails() const
{
	cout << name << " is at position ";
	position.printPoint();
	cout << ", is afflicted by " << affliction << " " << endl;
	cout << "and has a current score of " << score << "." << endl;
}


