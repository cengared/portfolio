// Daniel Stokoe, W0093152
// CP2, ICA, Beggar class defintion

#pragma once

#ifndef BEGGAR_H
#define BEGGAR_H
#include "point.h"
#include "player.h"

class Beggar: public Player{ //shows that this class is a child of the Player class
	public:
		Beggar(string n, string aff);
		void move();
		void evaluate(Point *t[], int s);
		void printDetails() const;
	private:
		string affliction;
};

#endif


