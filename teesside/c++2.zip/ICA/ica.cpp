// Daniel Stokoe, W0093152
// CP2, ICA, main function

#include <iostream>
#include <fstream> 	//allows use of file input & output
#include <string>
#include <cstdlib> 	//used to make RAND available
#include <ctime> 	//used to make RAND more random
#include <cctype>
using namespace std;
#include "knight.h"
#include "beggar.h"

//function prototype to show set of instructions
void instructions();

//function prototype to open treasure locations file
void openFile(ifstream &input);

//function prototype to fill the treasure location array
void setTreasureLocations(ifstream &input, Point *t[], int s);

//function prototype to add players
void getPlayers(Player *p[], int s);

//function prototype to run the end of game bit
void endGame(Player *p[], int s);

int main()
{
	ifstream inFile;
	char instruct;
	const int size = 0;

	srand((unsigned)time(0)); //to make a better random number generator 
	
	cout << "\nHello, welcome to Daniel Stokoe's CP2 ICA." << endl;
	cout << "\nWould you like instructions on how to play the game?" << endl;
	cout << "Enter Y for yes or N for no:" << endl;
	cin >> instruct;
	
	instruct = toupper(instruct); //makes character uppercase
	
	while (instruct != 'Y' && instruct != 'N')
	{
		cout << "\nError. Invalid selection." << endl;
		cout << "Please enter Y (yes) or N (no):" << endl;
		cin >> instruct;
		instruct = toupper(instruct);
	}
	
	if (instruct == 'Y')
	{
		cout << "\n\n" << endl;
		instructions();
	}
	else
	{
		cout << "\nOK, on with the game!\n" << endl;
	}
	
	openFile(inFile);
	
	inFile >> size;
	
	Point *treasure[size];
	
	setTreasureLocations(inFile, treasure, size);
	
	Player *players[5];
	
	getPlayers(players, 5);
	
	for (int i = 1; i < 4; i++)
	{
		cout << "\nBeginning round " << i << "." << endl;
		
		for (int j = 0; j < 5; j++)
		{
			players[j] -> move();
			players[j] -> evaluate(treasure, size);
		}
		
		cout << "\nCurrent player status is as follows:" << endl;
		cout << "\n" << endl;
		
		for (int j = 0; j < 5; j++)
		{
			players[j] -> printDetails();
		}
		
		cout << "\nEnd of round " << i << "." << endl;
		cout << "\n\n" << endl;
	}
	
	endGame(players, 5);
	
	return 0;
}

void instructions()
{
	char key;
	
	cout << "\nINSTRUCTIONS" << endl;
	cout << "\nTHE GAME" << endl;
	cout << "\nThis game is for 5 players." << endl;
	cout << "Before the start of the game, players are assigned two different characters." << endl;
	cout << "Players 1 and 3 are Knights. Players 2 and 4 are Beggars." << endl;
	cout << "The 5th player has the choice between being a Knight or a Beggar." << endl;
	cout << "The objective of the game is to get the highest score." << endl;
	cout << "Points are given by either finding treasure or for being near it," << endl;
	cout << "depending on your character." << endl;
	cout << "There are 20 treasure locations randomly spread out across the world." << endl;
	cout << "The world is 100 units across and 100 units up/down." << endl;
	cout << "Your location in the world is shown as a pair of co-ordinates like (14,25)" << endl;
	cout << "Movement is determined by how many units you want to move in the X axis" << endl;
	cout << "(east and west) and the Y axis (north and south)." << endl;
	cout << "For example, you are at (20,40) and you want to go to (10,60). You would"  << endl;
	cout << "need to enter -10 for the X direction and 20 for the Y direction." << endl;
	cout << "Simply put in the X directions positive numbers will send you west while"  << endl;
	cout << "negative numbers will move you east." << endl;
	cout << "It is similar for the Y directions - positive is north, negative is south." << endl;
	cout << "The game consists of three rounds in which each player moves once." << endl;
	cout << "After the three rounds the scores are compared and the highest score wins." << endl;
	cout << "If two or more players have the same score, the first player achieve" << endl;
	cout << "that score is declared the winner." << endl;
	cout << endl;
	
	cout << "Press any key & enter to continue on to Knights:";
	cin >> key;
	
	cout << "\n\nKNIGHTS" << endl;
	cout << "\nKnights carry armour which affects the distance they can travel" << endl;
	cout << "and the amount of points they get for finding treasure." << endl;
	cout << "If a Knight has armour weighing 100 lbs or more, then they can only" << endl;
	cout << "travel 30 units in each direction but they get 70 point for finding treasure." << endl;
	cout << "Knights carrying less than 100 lbs of armour can travel 40 units but" << endl;
	cout << "only get 50 points for finding treasure." << endl;
	cout << "After a Knight has found a treasure, it's location is removed from the game." << endl;
	cout << endl;
	
	cout << "Press any key & enter to continue on to Beggars:";
	cin >> key;
	
	cout << "\n\nBEGGARS" << endl;
	cout << "\nBeggars are different from Knights in that they wander randomly" << endl;
	cout << "through out the world. They have an afflicition but it doesn't do anything." << endl;
	cout << "To get points a Beggar must land within 5 units of a treasure location." << endl;
	cout << "If that happens, 10 points is awarded to the player." << endl;
	cout << "The treasure is not removed from the game unlike with Knights." << endl;
	cout << endl;
	
	cout << "Press any key & enter to return to the game:";
	cin >> key;

	return;	
}

void openFile(ifstream &input)
{
	input.open("treasure.txt");
    if (input.fail())
    {
        cout << "Error opening file." << endl;
        exit (1);
    }

    return;
}

void setTreasureLocations(ifstream &input, Point *t[], int s)
{
	int tempX, tempY;
	
	for (int i = 0; i < s; i++)
	{
		input >> tempX >> tempY;
		t[i] = new Point(tempX, tempY);
	}

}

void getPlayers(Player *p[], int s)
{
	string plyrName, ailment;
	int armourWeight;
	char pick;
	
	for (int i = 0; i < 4; i++)
	{
		cout << "\nPlayer " << i+1 << ", please enter your name:" << endl;
		cin >> plyrName;
		
		if (i % 2 == 0) //this means that player 1 & 3 will be knights, 2 & 4 will be beggars
		{
			cout << "Please enter the weight of armour you wish to carry:" << endl;
			cin >> armourWeight;
			p[i] = new Knight(plyrName, armourWeight);
		}
		else
		{
			cout << "Please enter your affliction:" << endl;
			cin >> ailment;
			p[i] = new Beggar(plyrName, ailment);
		}
	}
	
	cout << "\nPlayer 5, you have the choice to be a Knight or a Beggar." << endl;
	cout << "Which do you want to be?" << endl;
	cout << "Please enter K for Knight or B for Beggar." << endl;
	cin >> pick;
	
	pick = toupper(pick);
	
	//validating player choice
	while (pick != 'K' && pick != 'B')
	{
		cout << "\nError. Invalid selection." << endl;
		cout << "Please enter K (Knight) or B (Beggar):" << endl;
		cin >> pick;
		pick = toupper(pick);
	}
	
	cout << "\nPlayer 5, please enter your name:" << endl;
	cin >> plyrName;
	
	if (pick == 'K')
	{
		cout << "Please enter the weight of armour you wish to carry:" << endl;
		cin >> armourWeight;
		p[4] = new Knight(plyrName, armourWeight);
	}
	else
	{
		cout << "Please enter your affliction:" << endl;
		cin >> ailment;
		p[4] = new Beggar(plyrName, ailment);
	}

	return;
}


void endGame(Player *p[], int s)
{
	int temp, highscore = 0;
	string leader;
	
	//goes through all the players and finds the highest score	
	for (int i = 0; i < s; i++)
	{
		temp = p[i] -> getScore();
		if (temp > highscore)
		{
			highscore = temp;
			leader = p[i] -> getName();
		}
	}
	
	cout << "\n\nThe winner is " << leader << " with a score of " << highscore << "." << endl;
	cout << "\n\n\nGAME OVER" << endl;
	
	return;	
}

