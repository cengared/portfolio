// Daniel Stokoe, W0093152
// CP2, ICA, Knight class member functions

#include <iostream>
#include <string>
using namespace std;
#include "player.h"
#include "knight.h"
#include "point.h"

Knight::Knight(string n, int wt): Player(n)
{
	weight = wt;
}

//function to move the Knight players
void Knight::move() 
{
	int moveX, moveY, upLimit, downLimit;
	bool valid = false;
	
	//armour weight determines distance the player can travel
	if (weight >= 100) 
	{
		upLimit = 30;
		downLimit = -30;
	}
	else
	{
		upLimit = 40;
		downLimit = -40;
	}
	
	cout << "\nSir " << name << ". Please enter the distance you wish to move." << endl;
	cout << "Due to your armour weighing " << weight << " lbs you are restricted to moving" << endl;
	cout << upLimit << " units in either direction." << endl;
	
	//checking if user inputted values are valid - within distance limit
	while (!valid)
	{
		cout << "\nX direction: ";
		cin >> moveX;
		cout << "\nY direction: ";
		cin >> moveY;
		cout << "\n";
			
		if ((moveX > upLimit || moveX < downLimit) || (moveY > upLimit || moveY < downLimit))
		{
			valid = false;
			cout << "Error. You have entered distance greater than your movement limit." << endl;
			cout << "Please try again." << endl;
		}
		else
		{
			valid = true;
		}
	}
	
	//sends the user inputted data to the Point class
	//to change the player's current position
	position.adjust(moveX, moveY);
	
	return;	
}

//function used to award points to Knight players
void Knight::evaluate(Point *t[], int s)
{
	//loop to go through entire array of treasure location points
	for (int i = 0; i < s; i++)
	{
		if (position == *t[i])
		{
			cout << "\n** You have found treasure!!**\n" << endl;
			
			//weight determines how many points a Knight gets
			if (weight >= 100)
			{
				score += 70;
			}
			else
			{
				score += 50;
			}
			
			//once a treasure is found by a Knight it is removed
			delete t[i];
		}
		
	}
	
	return;
}

//function used to print the details of Knight players
void Knight::printDetails() const
{
	cout << "Sir " << name << " is at position ";
	position.printPoint();
	cout << ", has armour weighing " << weight << " lbs " << endl;
	cout << "and has a current score of " << score << "." << endl;
}


