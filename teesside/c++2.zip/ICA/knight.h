// Daniel Stokoe, W0093152
// CP2, ICA, Knight class defintion

#pragma once

#ifndef KNIGHT_H
#define KNIGHT_H
#include "point.h"
#include "player.h"

class Knight:public Player{ //shows that this class is a child of the Player class
	public:
		Knight(string n, int wt);
		void move();
		void evaluate(Point *t[], int s);
		void printDetails() const;
	private:
		int weight;
};

#endif


