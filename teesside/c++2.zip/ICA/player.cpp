// Daniel Stokoe, W0093152
// CP2, ICA, Player class member functions

#include <iostream>
#include <string>
using namespace std;
#include "player.h"

Player::Player(string n)
{
	name = n;
	position = Point(49,49);
	score = 0;
}

Player::Player()
{
	name = "default";
	position = Point(49,49);
	score = 0;
}

Player::~Player()
{
}

void Player::move()
{
//empty because this is a pure virtual function
}


void Player::evaluate(Point *t[], int s)
{
//empty because this is a pure virtual function
}

void Player::printDetails() const
{
//empty because this is a pure virtual function
}

Point Player::getLocation()
{
	return position;
}
