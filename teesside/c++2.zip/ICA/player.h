// Daniel Stokoe, W0093152
// CP2, ICA, Player class defintion

#pragma once

#ifndef PLAYER_H
#define PLAYER_H
#include "point.h"

class Player{
	public:
		Player(string n); 	
		Player(); 			
		virtual ~Player();	
		
		//the following are virtual functions which make this 
		//class an abstract class and these functions are used 
		//by the Knight & Beggar classes
		
		virtual void move();
		virtual void evaluate(Point *t[], int s);
		virtual void printDetails() const;
		
		Point getLocation();
		int getScore() {return score;}
		string getName() {return name;}
	protected:
		Point position;
		string name;
		int score;
};

#endif



