// Daniel Stokoe, W0093152
// CP2, ICA, Point class member functions

#include <iostream>
#include <cmath>
using namespace std;
#include "point.h"

// Point class object constructor
Point::Point(int xcoord, int ycoord) : x(xcoord), y(ycoord)
{
}

// Default constructor for Point class
Point::Point()
{
    x = 0;
    y = 0;
}

// Deconstructor for Point class objects
Point::~Point()
{
}

// Function used to move players
void Point::adjust(int addX, int addY)
{
    int temp = x + addX;

    if (temp >= 100)
    {
        x = 100;
    }
    else if (temp <= 0)
    {
        x = 0;
    }
    else
    {
        x += addX;
    }

    temp = y + addY;

    if (temp >= 100)
    {
        y = 100;
    }
    else if (temp <= 0)
    {
        y = 0;
    }
    else
    {
        y += addY;
    }

    return;
}

// Function used to determine distance from treasure location
double Point::operator - (const Point &p)
{
    double distX, distY;

    distX = x - p.x;
    distY = y - p.y;

   return sqrt(pow(distX, 2) + pow(distY, 2));

}

// Function used to see if position matches a treasure location
bool Point::operator == (const Point &p)
{
    if (x == p.x && y == p.y)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Function to print the position of a player
void Point::printPoint() const
{
    cout << "(" << x << ", " << y << ")";
    return;
}


