// Daniel Stokoe, W0093152
// CP2, ICA, Point class definition

#pragma once

#ifndef POINT_H
#define POINT_H

class Point{
    public:
        Point(int xcoord, int ycoord);
        Point();
        ~Point();
        void adjust(int addX, int addY);
        double operator - (const Point & p);
        bool operator == (const Point & p);
        void printPoint() const;
        int getX() {return x;}
        int getY() {return y;}
    protected:
        int x, y;
};

#endif

