HeliWars by Daniel Stokoe, 2nd Year student at the University of Teesside

INTRODUCTION:

Aliens are attacking Earth. And only you can stop them, in your trusty souped up helicopter. 
It�s HeliWars!!!

The aim of the game is to blast through the waves of alien ships and so reach their command 
ship. Once that is destroyed the world has been saved, for the time being.

Install the game by unzipping the package in a directory of your choosing. To run the game, 
double click the HeliWars executable file. After the game is loaded, you�ll see the title 
screen. To get straight into the action just press �S�. For a brief overview of the controls, 
press �I�. To change the difficultly level press �D�. To jump to another level press �W�. 
Finally, if you�re scared you can quit by pressing �X� which will show you the credits before 
letting you leave.

The controls for the helicopter are simple to learn but can be difficult to master. 
Pressing the right arrow (or D) key will cause the �copter to accelerate. Decelerate by 
pressing the left arrow (or A) key. To add more lift press up (or W) and to descend press 
down (or S). You fire by pressing the space bar (or right control key).

Points are awarded for every kill, with 100 points for the smaller ships and 1000 points 
for the control boss ship. You also start with a 1000 points of health. If a bullet from 
an enemy ship hits you, you�ll lose 10 points of health. You�ll lose 50 points of health 
from a hit from a boss ship. Another 50 points of health is the penalty for colliding with 
one of the small alien ships, though they�ll be destroyed themselves. Don�t collide with 
the control ship though as that will kill both of you.

Good luck out there, Earth is counting on you! 


VERSION NOTES:

Latest version is the build of 22.02.09

Build 22.02.09: Disabled level warp and difficulty selections until they're working correctly.


Build 06.01.09: 1st build, what was handed in for GS1 ICA. Provisional grade of A recieved. 


GAME NOTES:

God mode can be toggled with the I key.

The frame rate can be viewed by pressing the F key.




This readme is copyright Daniel Stokoe 22/02/09.
