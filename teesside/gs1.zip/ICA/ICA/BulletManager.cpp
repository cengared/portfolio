#include "BulletManager.h"
#include "Visualisation.h"
#include "World.h"
#include "Bullets.h"
#include "Rectangle.h"
#include "SoundManager.h"

// class that manages bullets

CBulletManager::CBulletManager()
{
	playerCount = 0;
	enemyCount = 0;
	bossCount = 0;
}

CBulletManager::~CBulletManager()
{
	for (unsigned int j = 0; j < playerBullets.size(); j++)
		delete playerBullets[j];

	for (unsigned int k = 0; k < enemyBullets.size(); k++)
		delete enemyBullets[k];

	for (unsigned int l = 0; l < bossBullets.size(); l++)
		delete bossBullets[l];
}

CBulletManager *CBulletManager::instance=NULL;

void CBulletManager::CreateInstance()
{
	instance = new CBulletManager();
}

CBulletManager &CBulletManager::GetInstance()
{
	return *instance;
}

void CBulletManager::DeleteInstance()
{
	delete instance;
}

void CBulletManager::LoadBullets(int l)
{
	CBullets *bullet;

	int id = VIZ.GetSpriteSize();

	VIZ.CreateSprite("bulletP.png"); // graphic id 54
	id++;
	for (int i = 1; i <= 10; i++)
	{
		bullet = new CBullets(id, 10);
		playerBullets.push_back(bullet);
	}

	VIZ.CreateSprite("bulletE.png"); // graphic id 55
	id++;
	for (int i = 1; i <= 50; i++)
	{
		bullet = new CBullets(id, (10+(l-1)*10));
		enemyBullets.push_back(bullet);
	}
	 
	VIZ.CreateSprite("bulletB.png"); // graphic id 56
	id++;
	for (int i = 1; i <= 25; i++)
	{
		bullet = new CBullets(id, (10+(l-1)*10));
		bossBullets.push_back(bullet);
	}
}

void CBulletManager::RenderBullets()
{
	bool player = false;

	for (unsigned int i = 0; i < playerBullets.size(); i++)
	{
		if (playerBullets[i]->IsActive())
		{
			VIZ.DrawSprite(playerBullets[i]->firePosX, playerBullets[i]->firePosY, 54);
			player = true;
			playerBullets[i]->Move(player);
		}
	}

	for (unsigned int i = 0; i < enemyBullets.size(); i++)
	{
		if (enemyBullets[i]->IsActive())
		{
			VIZ.DrawSprite(enemyBullets[i]->firePosX, enemyBullets[i]->firePosY, 55);
			player = false;
			enemyBullets[i]->Move(player);
		}
	}

	for (unsigned int i = 0; i < bossBullets.size(); i++)
	{
		if (bossBullets[i]->IsActive())
		{
			VIZ.DrawSprite(bossBullets[i]->firePosX, bossBullets[i]->firePosY, 56);
			player = false;
			bossBullets[i]->Move(player);
		}
	}
}

void CBulletManager::FirePlayer(int fireX, int fireY)
{
	if (playerCount < 10)
	{
		if (!playerBullets[playerCount]->IsActive())
		{
			playerBullets[playerCount]->Fire(fireX+125, fireY+31);
			SOUNDS.PlaySound(0);
		}
		playerCount++;
	}
	
	if (playerCount == 10)
		playerCount = 0;
}

void CBulletManager::FireEnemy(int fireX, int fireY)
{
	if (fireX <= 850)
	{
		if (enemyCount < 50)
		{
			if (!enemyBullets[enemyCount]->IsActive())
			{
				enemyBullets[enemyCount]->Fire(fireX+8, fireY+30);
				SOUNDS.PlaySound(1);
			}
			enemyCount++;
		}
	}

	if (enemyCount == 50)
		enemyCount = 0;
}

void CBulletManager::FireBoss(int fireX, int fireY)
{
	if (fireX <= 750)
	{
		if (bossCount < 25)
		{
			if (!bossBullets[bossCount]->IsActive())
			{
				bossBullets[bossCount]->Fire(fireX, fireY+112);
				SOUNDS.PlaySound(0);
			}
			bossCount++;
		}
	}

	if (bossCount == 25)
		bossCount = 0;
}

bool CBulletManager::PlayerBulletCollision(CRectangle *o)
{
	for (unsigned int i = 0; i < playerBullets.size(); i++)
	{
		if (playerBullets[i]->IsActive())
		{
			if (playerBullets[i]->Collided(o,16,16))
				return true;
		}
	}
	return false;
}

bool CBulletManager::EnemyBulletCollision(CRectangle *o)
{
	for (unsigned int i = 0; i < enemyBullets.size(); i++)
	{
		if (enemyBullets[i]->IsActive())
		{
			if (enemyBullets[i]->Collided(o,8,8))
				return true;
		}
	}
	return false;
}

bool CBulletManager::BossBulletCollision(CRectangle *o)
{
	for (unsigned int i = 0; i < bossBullets.size(); i++)
	{
		if (bossBullets[i]->IsActive())
		{
			if (bossBullets[i]->Collided(o,32,32))
				return true;
		}
	}
	return false;
}
