#pragma once

#include <vector>

class CBullets;
class CRectangle;

class CBulletManager 
{
public:
	static void CreateInstance();
	static CBulletManager &GetInstance();
	static void DeleteInstance();
	~CBulletManager();
	void LoadBullets(int l);
	void RenderBullets();
	void FirePlayer(int fireX, int fireY);
	void FireEnemy(int fireX, int fireY);
	void FireBoss(int fireX, int fireY);
	bool PlayerBulletCollision(CRectangle *o);
	bool EnemyBulletCollision(CRectangle *o);
	bool BossBulletCollision(CRectangle *o);
private:
	CBulletManager(void);
	static CBulletManager *instance;
	std::vector<CBullets*> playerBullets;
	std::vector<CBullets*> enemyBullets;
	std::vector<CBullets*> bossBullets;
	int playerCount;
	int enemyCount;
	int bossCount;
};

#define BULLETS CBulletManager::GetInstance()

