#pragma once
#include "BulletManager.h"
#include "Rectangle.h"

// holds bullet data

class CBullets
{
public:
	int firePosX, firePosY, graphicID, speed;
	bool active;

	CBullets() : graphicID(0), speed(0), firePosX(0), firePosY(0), active(false) {};
	CBullets(int id, int s) : graphicID(id), speed(s), firePosX(0), firePosY(0), active(false) {};
	
	bool IsActive() {return active;}

	void Fire(int x, int y)
	{
		active = true;
		firePosX = x;
		firePosY = y;
	}

	void Move(bool p) 
	{
		if (p)
		{
			firePosX+= speed/3;
			if (firePosX > 800)
				active = false;
		}
		else
		{
			firePosX-= speed/3;
			if (firePosX < 0)
				active = false;
		}
	}

	bool Collided(CRectangle *other, int width, int height)
	{
		CRectangle bullet(firePosX, firePosX+width, firePosY, firePosY+height);

		if ((bullet.right < other->left || bullet.left > other->right) || 
			(bullet.bottom < other->top || bullet.top > other->bottom))
			return false;
		else
		{
			active = false;
			return true;
		}
	}
};
