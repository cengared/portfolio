#include "ExplosionManager.h"
#include "Explosions.h"
#include "Visualisation.h"

// class that manages explosions

CExplosionManager::CExplosionManager()
{
	count = 0;
}

CExplosionManager::~CExplosionManager()
{
	for (unsigned int i = 0; i < explosions.size(); i++)
		delete explosions[i];
}

CExplosionManager *CExplosionManager::instance=NULL;

void CExplosionManager::CreateInstance()
{
	instance = new CExplosionManager();
}

CExplosionManager &CExplosionManager::GetInstance()
{
	return *instance;
}

void CExplosionManager::DeleteInstance()
{
	delete instance;
}

void CExplosionManager::LoadExplosions()
{
	CExplosions *explosion;

	int id = VIZ.GetSpriteSize();

	VIZ.CreateSprite("explosion1.png"); // graphic id 57
	for (int i = 0; i < 75; i++)
	{
		explosion = new CExplosions(id);
		explosions.push_back(explosion);
	}
	id++;
	VIZ.CreateSprite("explosion2.png"); // graphic id 58
	id++;
	VIZ.CreateSprite("explosion3.png"); // graphic id 59
	id++;
	VIZ.CreateSprite("explosion4.png"); // graphic id 60
	id++;
	VIZ.CreateSprite("explosion5.png"); // graphic id 61
}

void CExplosionManager::Explode(int x, int y)
{
	if (!explosions[count]->GetStatus())
	{
		explosions[count]->SetStatus(true);
		explosions[count]->SetXPos(x);
		explosions[count]->SetYPos(y);
	}

	count++;

}

void CExplosionManager::RenderExplosions()
{
	for (unsigned int i = 0; i < explosions.size(); i++)
	{
		if (explosions[i]->GetStatus())
			VIZ.DrawSprite(explosions[i]->GetXPos(),explosions[i]->GetYPos(),explosions[i]->GetGraphicID());
	}
}

void CExplosionManager::UpdateExplosions()
{
	for (unsigned int i = 0; i < explosions.size(); i++)
	{
		if (explosions[i]->GetStatus() && explosions[i]->GetGraphicID() < 61)
			explosions[i]->IterateGraphicID();			
	}
}