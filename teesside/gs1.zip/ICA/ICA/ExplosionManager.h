#pragma once

#include <vector>

class CExplosions;

class CExplosionManager
{
public:
	static void CreateInstance();
	static CExplosionManager &GetInstance();
	static void DeleteInstance();
	~CExplosionManager();
	void LoadExplosions();
	void Explode(int x, int y);
	void RenderExplosions();
	void UpdateExplosions();
private:
	CExplosionManager();
	static CExplosionManager *instance;
	std::vector<CExplosions*> explosions;
	int count;
};

#define EXPLOSIONS CExplosionManager::GetInstance()