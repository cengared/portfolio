#pragma once
#include "ExplosionManager.h"

// holds explosion data

class CExplosions
{
public:
	int graphicID;
	int xPos;
	int yPos;
	bool active;

	CExplosions() : graphicID(0), xPos(0), yPos(0), active(false) {};
	CExplosions(int id) : graphicID(id), xPos(0), yPos(0), active(false) {};

	void ResetExplosion() {graphicID = 13; active = false;}
	bool GetStatus() {return active;}
	void SetStatus(bool status) {active = status;}
	int GetXPos() {return xPos;}
	void SetXPos(int x) {xPos = x;}
	int GetYPos() {return yPos;}
	void SetYPos(int y) {yPos = y;}
	int GetGraphicID() {return graphicID;}
	void IterateGraphicID() {graphicID++;}
};
