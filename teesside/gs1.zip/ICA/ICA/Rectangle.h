#pragma once

// rectangle class, used in clipping

class CRectangle
{
public:
	int left, right, top, bottom;

	CRectangle(int l, int r, int t, int b) : left(l), right(r), top(t), bottom(b) {};
	CRectangle(const CRectangle &other): left(other.left), right(other.right), top(other.top), bottom(other.bottom) {};

	int width() const {return right-left;}
	int height() const {return bottom-top;}

	void Clip(const CRectangle &other)
	{
		if (left < other.left)
			left = other.left;
		if (right > other.right)
			right = other.right;
		if (top < other.top)
			top = other.top;
		if (bottom > other.bottom)
			bottom = other.bottom;

		return;
	}
	
	bool CompletelyContains(const int &x, const int &y, const CRectangle &other)
	{		
		if (x > 0 && x < right - other.width() && y > 0 &&  y < bottom - other.height())
			return true;
		else
			return false;
	}

	bool CompletelyOutside(const int &x, const int &y, const CRectangle &other)
	{
		if (x > right)
			return true;
		if (y > bottom)
			return true;
		if (x < left - other.width())
			return true;
		if (y < top - other.height())
			return true;

		return false;
	}
};
