#include <HAPI_lib.h>
#include "SoundManager.h"
#include "Sounds.h"

// class that manages sounds

CSoundManager::CSoundManager()
{
}

CSoundManager::~CSoundManager()
{
	for (unsigned int s = 0; s < sounds.size(); s++)
		delete sounds[s];
}

CSoundManager *CSoundManager::instance=NULL;

void CSoundManager::CreateInstance()
{
	instance = new CSoundManager();
}

CSoundManager &CSoundManager::GetInstance()
{
	return *instance;
}

void CSoundManager::DeleteInstance()
{
	delete instance;
}

void CSoundManager::LoadSounds()
{
	CSounds *sound;

	int id;

	// player fire sound, id 0
	if (!HAPI->LoadSound("fireP.wav", &id))
	{
		HAPI->UserMessage("fireP.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for fireP.wav");
	}

	// enemy fire sound, id 1
	if (!HAPI->LoadSound("fireE.wav", &id))
	{
		HAPI->UserMessage("fireE.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for fireE.wav");
	}

	// boss fire sound, id 2
	if (!HAPI->LoadSound("fireB.wav", &id))
	{
		HAPI->UserMessage("fireB.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for fireB.wav");
	}

	// enemy explosion sound, id 3
	if (!HAPI->LoadSound("boomE.wav", &id))
	{
		HAPI->UserMessage("boomE.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for boomE.wav");
	}

	// boss explosion sound, id 4
	if (!HAPI->LoadSound("boomB.wav", &id))
	{
		HAPI->UserMessage("boomE.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for boomE.wav");
	}

	// player or boss hit sound, id 5
	if (!HAPI->LoadSound("hit.wav", &id))
	{
		HAPI->UserMessage("hit.wav sound file not loaded.", "Sound error");
		return;
	}
	else
	{
		sound = new CSounds(id);
		sounds.push_back(sound);
		HAPI->DebugText("Sound loaded for hit.wav");
	}

}

void CSoundManager::PlaySound(int vectorID)
{
	HAPI->PlayASound(sounds[vectorID]->GetSoundID());
}

void CSoundManager::StopSound(int vectorID)
{
	HAPI->StopSound(sounds[vectorID]->GetSoundID());
}

void CSoundManager::PlayStreamed()
{
	HAPI->PlayStreamedMedia("someday.mp3");
}

void CSoundManager::StopStreamed()
{
	HAPI->StopStreamedMedia();
}