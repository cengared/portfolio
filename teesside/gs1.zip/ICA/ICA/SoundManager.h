#pragma once

#include <vector>

class CSounds;

class CSoundManager
{
public:
	static void CreateInstance();
	static CSoundManager &GetInstance();
	static void DeleteInstance();
	~CSoundManager();
	void LoadSounds();
	void PlaySound(int vectorID);
	void StopSound(int vectorID);
	void PlayStreamed();
	void StopStreamed();
private:
	CSoundManager();
	static CSoundManager *instance;
	std::vector<CSounds*> sounds;
};

#define SOUNDS CSoundManager::GetInstance()

