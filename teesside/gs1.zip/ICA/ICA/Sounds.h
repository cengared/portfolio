#pragma once
#include "SoundManager.h"

// holds sound data

class CSounds
{
public:
	int soundID;

	CSounds() : soundID(0) {};
	CSounds(int sID) : soundID(sID) {};
	
	int GetSoundID() {return soundID;}
};
