#include "Sprite.h"
#include "Rectangle.h"
#include <assert.h>

// class that holds sprite data

// constructors
CSprite::CSprite()
{
	textureWidth = 0;
	textureHeight = 0;
	spritePointer = 0;
}

CSprite::CSprite(int tWidth, int tHeight, BYTE *tPnter)
{
	textureWidth = tWidth;
	textureHeight = tHeight;
	spritePointer = tPnter;
}

// desctructor
CSprite::~CSprite()
{
	delete[] spritePointer;
}

// blit function
void CSprite::Blit(int posX, int posY, BYTE *screenPointer, int destWidth, int destHeight)
{
	assert(screenPointer!=0);
	assert(spritePointer!=0);

	// clip
	CRectangle sourceRect(0,textureWidth,0,textureHeight);
	CRectangle destRect(0,destWidth,0,destHeight);

	if (!destRect.CompletelyOutside(posX, posY, sourceRect)) // Do nothing if texture is to be completely off the screen
	{
		if (!destRect.CompletelyContains(posX, posY, sourceRect)) // Just normal alpha blit if texture completely on screen otherwise clip
		{
			// Convert source rectangle into screen space
			sourceRect.left += posX;
			sourceRect.right += posX;
			sourceRect.top += posY;
			sourceRect.bottom += posY;

			// Clip against the destination rectangle
			sourceRect.Clip(destRect);

			// Convert source rectangle back into source space
			sourceRect.left -= posX;
			sourceRect.right -= posX;
			sourceRect.top -= posY;
			sourceRect.bottom -= posY;

			// Clamp negative position values to zero
			if (posX < 0)
				posX = 0;
			if (posY < 0)
				posY = 0;
		}

		// blit
		BYTE *destPointer = screenPointer + (posX + posY * destWidth) * 4;
		BYTE *sourcePointer = spritePointer + (sourceRect.left + sourceRect.top * textureWidth) * 4;
		
		int destIncrement = (destWidth - sourceRect.width())*4;
		int sourceIncrement = (textureWidth - sourceRect.width())*4;

		for (int y = sourceRect.top; y < sourceRect.bottom; y++)
		{
			for (int x = sourceRect.left; x < sourceRect.right; x++)
			{
				BYTE blue = sourcePointer[0];
				BYTE green = sourcePointer[1];
				BYTE red = sourcePointer[2];
				BYTE alpha = sourcePointer[3];

				if (alpha > 0) // Do nothing, background texture is fine
				{
					if (alpha == 255) // Copy all of source texture, no alpha change needed
					{
						memcpy (destPointer, sourcePointer, 4);
					}
					else
					{
						// Bit shifting by 8 (>> 8) - effectively dividing by 256
						destPointer[0] = destPointer[0]+((alpha*(blue-destPointer[0])) >> 8);
						destPointer[1] = destPointer[1]+((alpha*(green-destPointer[1])) >> 8);
						destPointer[2] = destPointer[2]+((alpha*(red-destPointer[2])) >> 8);
					}	
				}

				sourcePointer += 4;
				destPointer += 4;
			}

			destPointer += destIncrement;
			sourcePointer += sourceIncrement;
		}
	}
	return;
}
