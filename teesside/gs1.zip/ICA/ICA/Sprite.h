#pragma once

#include <vector>

typedef unsigned char BYTE;

class CSprite
{
public:
	CSprite();
	CSprite(int tWidth, int tHeight, BYTE *tPnter);
	~CSprite();
	void Blit(int posX, int posY, BYTE *screenPointer, int destWidth, int destHeight);
	int GetTextureWidth() {return textureWidth;}
	int GetTextureHeight() {return textureHeight;}
private:
	int textureWidth;
	int textureHeight;
	int spriteID;
	BYTE *spritePointer;
};
