#pragma once

#include <math.h>

/*
A simple 2D vector class
Feel free to use and modify as you require.
Keith
*/
class CVector2
{
public:
	float x,y;

	// Constructors
	CVector2(void) : x(0),y(0) {}
	CVector2(float xin,float yin) : x(xin),y(yin) {}
	CVector2(const CVector2 &other) : x(other.x), y(other.y) {}

	// Operators
	const CVector2 & CVector2::operator -=(const CVector2 &rhs)
	{
		x-=rhs.x;
		y-=rhs.y;
		return *this;
	};

	const CVector2 & CVector2::operator +=(const CVector2 &rhs)
	{
		x+=rhs.x;
		y+=rhs.y;
		return *this;
	};

	const CVector2 & CVector2::operator /=(const CVector2 &rhs)
	{
		x/=rhs.x;
		y/=rhs.y;
		return *this;
	};

	const CVector2 & CVector2::operator *=(const CVector2 &rhs)
	{
		x*=rhs.x;
		y*=rhs.y;
		return *this;
	};

	const CVector2 & CVector2::operator *=(float f)
	{
		x*=f;
		y*=f;
		return *this;
	};

	const CVector2 operator -(const CVector2 &rhs) const
	{
		CVector2 ret(*this);
		ret-=rhs;
		return ret;
	}

	const CVector2 operator +(const CVector2 &rhs) const
	{
		CVector2 ret(*this);
		ret+=rhs;
		return ret;
	}

	const CVector2 operator /(const CVector2 &rhs) const
	{
		CVector2 ret(*this);
		ret/=rhs;
		return ret;
	}

	const CVector2 operator *(const CVector2 &rhs) const
	{
		CVector2 ret(*this);
		ret*=rhs;
		return ret;
	}

	const CVector2 operator *(const float &fl) const
	{
		CVector2 ret(*this);
		ret.x*=fl;
		ret.y*=fl;
		return ret;
	}

	bool operator == (const CVector2& c) const 
	{
		if (c.x!=x || c.y!=y)
			return false;

		return true;
	}

	// Functions

	// Vector length
	float Length() const {return sqrt(x*x+y*y);} const

	// Squared length
	float SquaredLength() const {return x*x+y*y;} const
	
	// Normalise this vector
	void Normalise() 
	{
		float len=Length();
		if(len==0) 
			return;

		x/=len;
		y/=len;
	}

	// Calculates cosine angle between two vectors
	float Dot(const CVector2& other) const
	{
		return x * other.x + y * other.y;
	}

	// Calculates the 2D cross product of 2 vectors resulting in a float which is 2 times the the area of the triangle
    float Cross( const CVector2& other) const
    {
        return x * other.y - y * other.x;
    }
	~CVector2(void){};
};
