#include <HAPI_lib.h>
#include <vector>
#include <string>
#include "Visualisation.h"
#include "Sprite.h"

// main part of visualisation component

// constructor
CVisualisation::CVisualisation()
{
	screenWidth = 0;
	screenHeight = 0;
	screenPointer = 0;
}

// destructor
CVisualisation::~CVisualisation()
{
	HAPI->DebugText("Deleting sprites");
	for (unsigned int p = 0; p < sprites.size(); p++)
		delete sprites[p];
	for (unsigned int p = 0; p < otherSprites.size(); p++)
		delete otherSprites[p];
}

// the following are used to create a singleton of the Visualisation class
CVisualisation *CVisualisation::instance=NULL;

void CVisualisation::CreateInstance()
{
	instance = new CVisualisation();
}

CVisualisation &CVisualisation::GetInstance()
{
	return *instance;
}

void CVisualisation::DeleteInstance()
{
	delete instance;
}

// visualisation initialisation
bool CVisualisation::InitialiseVis(int width, int height)
{
	screenWidth = width;
	screenHeight = height;

	if (!HAPI->Initialise(&screenWidth, &screenHeight))
	{
		HAPI->DebugText("HAPI failed to initialise.");
		return false;
	}
	else
	{
		HAPI->DebugText("Visualisation initialised OK");
		screenPointer = HAPI->GetScreenPointer();
		return true;	
	}
}

// function that creates and stores a sprite in the sprites vector
void CVisualisation::CreateSprite(std::string name)
{	
	BYTE *texture=0;
	int tW, tH;
	if (!HAPI->LoadTexture(name, &texture, &tW, &tH))
	{
		HAPI->UserMessage(name + " texture not loaded.", "Texture error");
		return;
	}
	
	id = sprites.size();

	CSprite *sprite = new CSprite(tW, tH, texture);

	sprites.push_back(sprite);

	HAPI->DebugText("Sprite created for " + name + " texture file");
	
	return;
}

// function calls the CSprite blit function
void CVisualisation::DrawSprite(int x, int y, int drawID)
{
	sprites[drawID]->Blit(x, y, screenPointer, screenWidth, screenHeight);
}

void CVisualisation::SpriteWidthHeight(int &w, int &h, int gID)
{
	w = sprites[id]->GetTextureWidth();
	h = sprites[id]->GetTextureHeight();
}

void CVisualisation::RenderText(std::string text, int x, int y)
{
	HAPI_TColour textCol(255,0,0);
	HAPI->ChangeFont("System",50,900);

	HAPI->RenderText(x,y,textCol,text);
}

void CVisualisation::LoadMenu()
{
	BYTE *texture=0;
	int tW, tH;
	CSprite *otherSprite;

	// title screen - otherSprites entity 0
	if (!HAPI->LoadTexture("title.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("title.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for title.png texture file");

	// instruction screen - otherSprites entity 1
	if (!HAPI->LoadTexture("instruct.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("instruct.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for instruct.png texture file");

	// difficulty screen - otherSprites entity 2
	if (!HAPI->LoadTexture("difficulty.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("difficulty.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for difficulty.png texture file");

	// level screen - otherSprites entity 3
	if (!HAPI->LoadTexture("level.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("level.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for level.png texture file");

	// gameover screen - otherSprites entity 4
	if (!HAPI->LoadTexture("gameover.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("gameover.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for gameover.png texture file");

	// youwin screen - otherSprites entity 5
	if (!HAPI->LoadTexture("youwin.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("youwin.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for youwin.png texture file");

	// credits screen - otherSprites entity 6
	if (!HAPI->LoadTexture("credits.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("credits.png texture not loaded.", "Texture error");
		return;
	}
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for credits.png texture file");


}

void CVisualisation::DrawMenu(int choice)
{
	otherSprites[choice]->Blit(0, 0, screenPointer, screenWidth, screenHeight);
}

void CVisualisation::LoadHUD()
{
	BYTE *texture=0;
	int tW, tH, num;
	CSprite *otherSprite;

	// health text - otherSprites entity 7
	if (!HAPI->LoadTexture("health.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("health.png texture not loaded.", "Texture error");
		return;
	}
	num = otherSprites.size();
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for health.png texture file");

	// score text - otherSprites entity 8
	if (!HAPI->LoadTexture("score.png", &texture, &tW, &tH))
	{
		HAPI->UserMessage("score.png texture not loaded.", "Texture error");
		return;
	}
	num = otherSprites.size();
	otherSprite = new CSprite(tW, tH, texture);
	otherSprites.push_back(otherSprite);
	HAPI->DebugText("Sprite created for score.png texture file");

	return;
}

void CVisualisation::DrawHUD()
{
	otherSprites[7]->Blit(15, 560, screenPointer, screenWidth, screenHeight);
	otherSprites[8]->Blit(415, 560, screenPointer, screenWidth, screenHeight);
}