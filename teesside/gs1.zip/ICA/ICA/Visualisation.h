#pragma once

#include <vector>

// forward declaring CSprite class
class CSprite;

// create type definition of a BYTE
typedef unsigned char BYTE;

class CVisualisation
{
public:
	static void CreateInstance();
	static CVisualisation &GetInstance();
	static void DeleteInstance();
	~CVisualisation();
	bool InitialiseVis(int width, int height);
	void CreateSprite(std::string name);
	void DrawSprite(int x, int y, int drawID);
	int GetSpriteSize() {return sprites.size();}
	void SpriteWidthHeight(int &w, int &h, int gID);
	void RenderText(std::string text, int x, int y);
	void LoadMenu();
	void DrawMenu(int choice);
	void LoadHUD();
	void DrawHUD();
private:
	CVisualisation();
	static CVisualisation *instance;
	int screenWidth;
	int screenHeight;
	int id;
	BYTE *screenPointer;
	std::vector<CSprite*> sprites;
	std::vector<CSprite*> otherSprites;
};

#define VIZ CVisualisation::GetInstance()

