#include "World.h"
#include "WorldEntity.h"
#include "Visualisation.h"
#include <string>
#include <sstream>
#include "WorldEntityBackground.h"
#include "WorldEntityPlayer.h"
#include "WorldEntityEnemy.h"
#include "WorldEntityBoss.h"
#include "BulletManager.h"
#include "ExplosionManager.h"

// main part of world component

CWorld::CWorld()
{
	CBulletManager::CreateInstance();
	CExplosionManager::CreateInstance();
	score = 0;
}

CWorld::~CWorld()
{
	// delete entities
	for (unsigned int i = 0; i < entities.size(); i++)
		delete entities[i];

	BULLETS.DeleteInstance();
	EXPLOSIONS.DeleteInstance();
}

// singleton
CWorld *CWorld::instance=NULL;

void CWorld::CreateInstance()
{
	instance = new CWorld();
}

CWorld &CWorld::GetInstance()
{
	return *instance;
}

void CWorld::DeleteInstance()
{
	delete instance;
}

// loads all the entities used in a level
void CWorld::LoadLevel(int l, int d)
{
	int id = entities.size();
	int enemyX, enemyY;
	CWorldEntity *entity;
	
	// background
	VIZ.CreateSprite("background.png");// graphic id 0
	entity = new CWorldEntityBackground(0,id,0,0,0,0,0);
	entities.push_back(entity); // entity 0
	id++;
	
	// player
	VIZ.CreateSprite("player1.png"); // graphic id 1
	entity = new CWorldEntityPlayer(1,id,25,75,1000,20,250);
	entities.push_back(entity); // entity 1
	id++;
	for (int i = 2; i <= 4; i++)
	{
		VIZ.CreateSprite("player" + toString(i) + ".png"); // graphic id 2-4
		id++;
	}

	// enemies
	VIZ.CreateSprite("enemyA1.png"); // graphic id 5
	enemyX = 1000;
	enemyY = 111;
	for (int i = 1; i <=5; i++) // enemyA, group 1
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(50+(d-1)*50),(30+(l-1)*10),50);
		entities.push_back(entity); // entities 2-6
		enemyX += 100;
	}
	enemyX += 700;
	enemyY = 222;
	for (int i = 1; i <=5; i++) // enemyA, group 2
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(50+(d-1)*50),(30+(l-1)*10),50);
		entities.push_back(entity); // entities 7-11
		enemyX += 100;
	}
	enemyX += 700;
	enemyY = 333;
	for (int i = 1; i <=5; i++) // enemyA, group 3
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(50+(d-1)*50),(30+(l-1)*10),50);
		entities.push_back(entity); // entities 12-16
		enemyX += 100;
	}
	enemyX += 700;
	enemyY = 444;
	for (int i = 1; i <=5; i++) // enemyA, group 4
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(50+(d-1)*50),(30+(l-1)*10),50);
		entities.push_back(entity); // entities 17-21
		enemyX += 100;
	}
	id++;
	for (int i = 2; i <=16; i++)
	{
		VIZ.CreateSprite("enemyA" + toString(i) + ".png"); // graphic id 6-20
		id++;
	}

	VIZ.CreateSprite("enemyB1.png"); // graphic id 21
	enemyX = 6500;
	enemyY = 278;
	for (int i = 1; i <=5; i++) // enemyB, group 1
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(100+(d-1)*50),(35+(l-1)*10),50);
		entities.push_back(entity); // entities 22-26
		enemyX += 100;
	}
	enemyX += 600;
	enemyY = 345;
	for (int i = 1; i <=5; i++) // enemyB, group 2
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(100+(d-1)*50),(35+(l-1)*10),50);
		entities.push_back(entity); // entities 27-31
		enemyX += 100;
	}
	enemyX += 600;
	enemyY = 129;
	for (int i = 1; i <=5; i++) // enemyB, group 3
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(100+(d-1)*50),(35+(l-1)*10),50);
		entities.push_back(entity); // entities 32-36
		enemyX += 100;
	}
	enemyX += 600;
	enemyY = 455;
	for (int i = 1; i <=5; i++) // enemyB, group 4
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(100+(d-1)*50),(35+(l-1)*10),50);
		entities.push_back(entity); // entities 37-41
		enemyX += 100;
	}
	id++;
	for (int i = 2; i <=16; i++)
	{
		VIZ.CreateSprite("enemyB" + toString(i) + ".png"); // graphic id 22-36
		id++;
	}

	VIZ.CreateSprite("enemyC1.png"); // graphic id 37
	enemyX = 13000;
	enemyY = 100;
	for (int i = 1; i <=5; i++) // enemyC, group 1
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(150+(d-1)*50),(40+(l-1)*10),50);
		entities.push_back(entity); // entities 42-46
		enemyX += 100;
	}
	enemyX += 500;
	enemyY = 233;
	for (int i = 1; i <=5; i++) // enemyC, group 2
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(150+(d-1)*50),(40+(l-1)*10),50);
		entities.push_back(entity); // entities 47-51
		enemyX += 100;
	}
	enemyX += 500;
	enemyY = 366;
	for (int i = 1; i <=5; i++) // enemyC, group 3
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(150+(d-1)*50),(40+(l-1)*10),50);
		entities.push_back(entity); // entities 52-56
		enemyX += 100;
	}
	enemyX += 500;
	enemyY = 500;
	for (int i = 1; i <=5; i++) // enemyC, group 4
	{
		entity = new CWorldEntityEnemy(2,id,enemyX,enemyY,(150+(d-1)*50),(40+(l-1)*10),50);
		entities.push_back(entity); // entities 57-61
		enemyX += 100;
	}
	id++;
	for (int i = 2; i <=16; i++)
	{
		VIZ.CreateSprite("enemyC" + toString(i) + ".png"); // graphic id 37-52
		id++;
	}

	// boss
	VIZ.CreateSprite("boss.png");// graphic id 53
	entity = new CWorldEntityBoss(2,id,11000,142,(500+(d-1)*100),(35+(l-1)*10),1000);
	entities.push_back(entity); // entity 62
	id++;

	BULLETS.LoadBullets(l);
	EXPLOSIONS.LoadExplosions();
}

// updates all the entities
void CWorld::UpdateWorld(int mX, int mY, bool pF, bool pE, bool gM, bool &gO, bool &w)
{
	for (unsigned int i = 0; i < entities.size(); i++)
	{
		if (!entities[i]->IsDead())
		{
			entities[i]->Move(mX, mY);
			entities[i]->Update(score);
		}
	}

	if (pF)
		entities[1]->Fire();

	if (pE)
	{
		for (unsigned int i = 2; i < entities.size(); i++)
		{
			if (!entities[i]->IsDead())
				entities[i]->Fire();
		}
	}

	if (gM)
	{
		if (entities[1]->GetHealth() < 500)
			entities[1]->SetHealth(-500);
	}

	EXPLOSIONS.UpdateExplosions();

	if (entities[1]->IsDead())
		gO = true;

	if (entities[62]->IsDead())
		w = true;
}

// makes every entity call their CollisionCheck functions
void CWorld::CheckCollisions()
{
	for (unsigned int i = 2; i < entities.size(); i++)
	{	
		if (!entities[i]->IsDead())
			entities[i]->CollisionCheck(entities[1],128,64);
	}

	entities[1]->CollisionCheck(entities[0],0,0);
}

// sends render date of the game world to the visualisation component
void CWorld::RenderWorld()
{
	int x, y, id;
	
	for (unsigned int i = 0; i < entities.size(); i++)
	{
		entities[i]->Render(x, y, id);
		if (!(entities[i]->IsDead()))
			VIZ.DrawSprite(x,y,id);
	}
	
	BULLETS.RenderBullets();
	EXPLOSIONS.RenderExplosions();

	VIZ.RenderText(toString(entities[1]->GetHealth()),195,551);
	VIZ.RenderText(toString(score),575,551);
}
// small function used to make a int into a string
std::string toString(int val)
{
	std::ostringstream stream;
	stream << val;
	return stream.str();
}