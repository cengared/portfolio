#pragma once

#include <vector>

class CWorldEntity;

class CWorld
{
public:
	static void CreateInstance();
	static CWorld &GetInstance();
	static void DeleteInstance();
	enum ESide {eSideNeutral,eSidePlayer,eSideEnemy};
	~CWorld();
	void LoadLevel(int levelNum, int diff);
	void UpdateWorld(int mX, int mY, bool pF, bool eF, bool gM, bool &gO, bool &w);
	void CheckCollisions();
	void RenderWorld();
	ESide getSide() {return side;}
private:
	CWorld();
	static CWorld *instance;
	std::vector<CWorldEntity*> entities;
	ESide side;
	int score;
};

#define WORLD CWorld::GetInstance()

std::string toString(int val);
