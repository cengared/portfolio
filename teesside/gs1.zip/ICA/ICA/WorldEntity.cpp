#include "WorldEntity.h"

// base entity class from which all other entity classes are derived

CWorldEntity::CWorldEntity()
{
	entitySide = 0;
	graphicID = 0;
	xPos = 0;
	yPos = 0;
	health = 0;
	speed = 0;
	collisionCost = 0;
	killed = false;
}

CWorldEntity::~CWorldEntity()
{
}

void CWorldEntity::Move(int moveX, int moveY)
{
}

void CWorldEntity::Update(int &s)
{
}

void CWorldEntity::Render(int &x, int &y, int &id)
{
}

void CWorldEntity::CollisionCheck(CWorldEntity *other, int width, int height)
{
}

void CWorldEntity::Fire()
{
}
