#pragma once

class CWorldEntity
{
public:
	CWorldEntity();
	virtual ~CWorldEntity();
	virtual void Move(int moveX, int moveY) = 0;
	virtual void Update(int &s) = 0;
	virtual void Render(int &x, int &y, int &id) = 0;
	virtual void CollisionCheck(CWorldEntity *other, int width, int height) = 0;
	virtual void Fire() = 0;
	virtual bool IsDead() {return killed;}
	virtual int GetXPos() {return xPos;}
	virtual int GetYPos() {return yPos;}
	virtual int GetHealth() {return health;}
	virtual int GetCollisionCost() {return collisionCost;}
	virtual int GetGraphicID() {return graphicID;}
	virtual void SetHealth(int value) {health -= value;}
protected:
	int entitySide; 
	int graphicID;
	int xPos;
	int yPos;
	int health;
	int speed;
	int collisionCost;
	bool killed;
};
