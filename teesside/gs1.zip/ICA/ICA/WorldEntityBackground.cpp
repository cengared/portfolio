#include "WorldEntityBackground.h"

// class for the background entity

CWorldEntityBackground::CWorldEntityBackground(int eS, int gID, int x, int y, int h, int s, int c)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	killed = false;
}

CWorldEntityBackground::~CWorldEntityBackground()
{
}

void CWorldEntityBackground::Move(int moveX, int moveY)
{
}

void CWorldEntityBackground::Update(int &s)
{
}

void CWorldEntityBackground::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

void CWorldEntityBackground::CollisionCheck(CWorldEntity *other, int width, int height)
{
}

void CWorldEntityBackground::Fire()
{
}
