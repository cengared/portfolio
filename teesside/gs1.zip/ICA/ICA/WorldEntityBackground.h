#pragma once
#include "WorldEntity.h"

class CWorldEntityBackground : public CWorldEntity
{
public:
	CWorldEntityBackground(int eS, int gID, int x, int y, int h, int s, int c);
	~CWorldEntityBackground();
	void Move(int moveX, int moveY);
	void Update(int &s);
	void Render(int &x, int &y, int &id);
	void CollisionCheck(CWorldEntity *other, int width, int height);
	void Fire();
	bool IsDead() {return killed;}
	int GetXPos() {return xPos;}
	int GetYPos() {return yPos;}
	int GetHealth() {return health;}
	int GetCollisionCost() {return collisionCost;}
	int GetGraphicID() {return graphicID;}
	void SetHealth(int value) {health -= value;}
private:
	int entitySide;
	int xPos;
	int yPos;
	int graphicID;
	int health;
	int speed;
	int collisionCost;
	bool killed;
};
