#include "WorldEntityBoss.h"
#include "BulletManager.h"
#include "ExplosionManager.h"
#include "SoundManager.h"
#include "Rectangle.h"

// class for the boss entity

CWorldEntityBoss::CWorldEntityBoss(int eS, int gID, int x, int y, int h, int s, int c)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	killed = false;
}

CWorldEntityBoss::~CWorldEntityBoss()
{
}

void CWorldEntityBoss::Move(int moveX, int moveY)
{
	if (xPos > 550)
		xPos -= speed/4;
}

void CWorldEntityBoss::Update(int &s)
{
	if (health <= 0)
	{
		killed = true;
		s += 1000;
		EXPLOSIONS.Explode(xPos+80, yPos+115);
		SOUNDS.PlaySound(4);
	}
}

void CWorldEntityBoss::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

void CWorldEntityBoss::CollisionCheck(CWorldEntity *other, int width, int height)
{
	bool collided = false;

	CRectangle boss(xPos, xPos+256, yPos, yPos+256);
	
	int otherX = other->GetXPos();
	int otherY = other->GetYPos();
	CRectangle otherRectangle(otherX, otherX+width, otherY, otherY+height);

	if ((boss.right < otherRectangle.left || boss.left > otherRectangle.right) 
		|| (boss.bottom < otherRectangle.top || boss.top > otherRectangle.bottom))
		collided = false;
	else
		collided = true;

	if (collided)
	{
		health -= other->GetCollisionCost();
		other->SetHealth(collisionCost);
		collided = false;
	}

	if (BULLETS.PlayerBulletCollision(&boss))
	{
		SOUNDS.PlaySound(5);
		health -= 50;
	}
}

void CWorldEntityBoss::Fire()
{
	BULLETS.FireBoss(xPos, yPos);
}