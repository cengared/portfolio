#include "WorldEntityBossBullet.h"

CWorldEntityBossBullet::CWorldEntityBossBullet(int eS, int gID, int x, int y, int h, int s, int c, int f)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	numOfFrames = f;
}

CWorldEntityBossBullet::~CWorldEntityBossBullet()
{
}

void CWorldEntityBossBullet::Move()
{
}

void CWorldEntityBossBullet::Update()
{
}

void CWorldEntityBossBullet::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

bool CWorldEntityBossBullet::CollisionCheck(CWorldEntity *other)
{
	return true;
}
