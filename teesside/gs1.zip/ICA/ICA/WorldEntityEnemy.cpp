#include "WorldEntityEnemy.h"
#include "BulletManager.h"
#include "ExplosionManager.h"
#include "SoundManager.h"
#include "Rectangle.h"

// class for the enemy entities

CWorldEntityEnemy::CWorldEntityEnemy(int eS, int gID, int x, int y, int h, int s, int c)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	killed = false;
}

CWorldEntityEnemy::~CWorldEntityEnemy()
{
}

void CWorldEntityEnemy::Move(int moveX, int moveY)
{
	if (xPos > -100)
		xPos -= speed/3;
}

void CWorldEntityEnemy::Update(int &s)
{
	if (health <= 0)
	{
		killed = true;
		s += 100;
		EXPLOSIONS.Explode(xPos+20, yPos+20);
		SOUNDS.PlaySound(3);
	}
}

void CWorldEntityEnemy::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

void CWorldEntityEnemy::CollisionCheck(CWorldEntity *other, int width, int height)
{	
	bool collided = false;

	CRectangle enemy(xPos, xPos+64, yPos, yPos+64);
	
	int otherX = other->GetXPos();
	int otherY = other->GetYPos();
	CRectangle otherRectangle(otherX, otherX+width, otherY, otherY+height);

	if ((enemy.right < otherRectangle.left || enemy.left > otherRectangle.right) 
		|| (enemy.bottom < otherRectangle.top || enemy.top > otherRectangle.bottom))
		collided = false;
	else
		collided = true;

	if (collided)
	{
		health -= other->GetCollisionCost();
		other->SetHealth(collisionCost);
		collided = false;
	}

	if (BULLETS.PlayerBulletCollision(&enemy))
		health -= 50;

}

void CWorldEntityEnemy::Fire()
{
	BULLETS.FireEnemy(xPos, yPos);
}
