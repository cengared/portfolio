#include "WorldEntityEnemyBullet.h"

CWorldEntityEnemyBullet::CWorldEntityEnemyBullet(int eS, int gID, int x, int y, int h, int s, int c, int f)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	numOfFrames = f;
}

CWorldEntityEnemyBullet::~CWorldEntityEnemyBullet()
{
}

void CWorldEntityEnemyBullet::Move()
{
}

void CWorldEntityEnemyBullet::Update()
{
}

void CWorldEntityEnemyBullet::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

bool CWorldEntityEnemyBullet::CollisionCheck(CWorldEntity *other)
{
	return true;
}
