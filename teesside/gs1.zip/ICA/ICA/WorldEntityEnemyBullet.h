#pragma once
#include "WorldEntity.h"

class CWorldEntityEnemyBullet : public CWorldEntity
{
public:
	CWorldEntityEnemyBullet(int eS, int gID, int x, int y, int h, int s, int c, int f);
	~CWorldEntityEnemyBullet();
	void Move();
	void Update();
	void Render(int &x, int &y, int &id);
	bool CollisionCheck(CWorldEntity *other);
private:
	int entitySide;
	int xPos;
	int yPos;
	int graphicID;
	int health;
	int speed;
	int collisionCost;
	int numOfFrames;
};