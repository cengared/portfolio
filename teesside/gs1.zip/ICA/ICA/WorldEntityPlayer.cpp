#include "WorldEntityPlayer.h"
#include "BulletManager.h"
#include "ExplosionManager.h"
#include "SoundManager.h"
#include "Rectangle.h"

// class for the player entity

CWorldEntityPlayer::CWorldEntityPlayer(int eS, int gID, int x, int y, int h, int s, int c)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	killed = false;
}

CWorldEntityPlayer::~CWorldEntityPlayer()
{
}

void CWorldEntityPlayer::Move(int moveX, int moveY)
{
	xPos += moveX;
	if (xPos < -50)
		xPos = -50;
	if (xPos > 672)
		xPos = 672;
	yPos += moveY;
	if (yPos < -10)
		yPos = -10;
	if (yPos > 550)
		yPos = 550;
}

void CWorldEntityPlayer::Update(int &s)
{
	graphicID++;
	if (graphicID == 5)
		graphicID = 1;
	if (health <= 0)
	{
		killed = true;
		EXPLOSIONS.Explode(xPos+70, yPos+20);
	}
}

void CWorldEntityPlayer::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

void CWorldEntityPlayer::CollisionCheck(CWorldEntity *other, int width, int height)
{
	CRectangle player(xPos, xPos+128, yPos, yPos+64);
	
	if (BULLETS.EnemyBulletCollision(&player))
	{
		SOUNDS.PlaySound(5);
		health -= 10;
	}

	if (BULLETS.BossBulletCollision(&player))
	{
		SOUNDS.PlaySound(5);
		health -= 50;
	}
}

void CWorldEntityPlayer::Fire()
{
	BULLETS.FirePlayer(xPos, yPos);
}