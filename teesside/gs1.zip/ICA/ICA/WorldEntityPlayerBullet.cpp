#include "WorldEntityPlayerBullet.h"

CWorldEntityPlayerBullet::CWorldEntityPlayerBullet(int eS, int gID, int x, int y, int h, int s, int c, int f)
{
	entitySide = eS;
	graphicID = gID;
	xPos = x;
	yPos = y;
	health = h;
	speed = s;
	collisionCost = c;
	numOfFrames = f;
}

CWorldEntityPlayerBullet::~CWorldEntityPlayerBullet()
{
}

void CWorldEntityPlayerBullet::Move()
{
}

void CWorldEntityPlayerBullet::Update()
{
}

void CWorldEntityPlayerBullet::Render(int &x, int &y, int &id)
{
	x = xPos;
	y = yPos;
	id = graphicID;
}

bool CWorldEntityPlayerBullet::CollisionCheck(CWorldEntity *other)
{
	return true;
}
