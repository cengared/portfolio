#pragma once
#include "worldentity.h"

class CWorldEntityPlayerBullet : public CWorldEntity
{
public:
	CWorldEntityPlayerBullet(int eS, int gID, int x, int y, int h, int s, int c, int f);
	~CWorldEntityPlayerBullet();
	void Move();
	void Update();
	void Render(int &x, int &y, int &id);
	bool CollisionCheck(CWorldEntity *other);
private:
	int entitySide;
	int xPos;
	int yPos;
	int graphicID;
	int health;
	int speed;
	int collisionCost;
	int numOfFrames;
};
