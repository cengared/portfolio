// Daniel Stokoe, W0093152, Games Software Development 1, ICA

#include <HAPI_lib.h>
#include "Visualisation.h"
#include "World.h"
#include "SoundManager.h"

// constant variables
const DWORD kDelay=100;

// functions
void Menu(bool &s, bool &e, int &l, int &d);

int DifficultyChooser();

int LevelChooser();

void HAPI_Main()
{
	srand(HAPI->GetTime()); 
	CVisualisation::CreateInstance();
	CWorld::CreateInstance();
	CSoundManager::CreateInstance();

	VIZ.InitialiseVis(800,600);
	VIZ.LoadMenu();

	DWORD lastCheck = 0;
	HAPI_TKeyboardData keyData;

	int playerX = 0, playerY = 0;
	bool playerFire = false;
	bool godMode = false;
	bool showFPS = false;
	int enemyRand = 0;
	bool enemyFire = false;
	bool startGame = false;
	bool exitGame = false;
	bool win = false;
	bool gameOver = false;
	int level = 1;
	int diff = 1;
	
	SOUNDS.PlayStreamed();

	Menu(startGame, exitGame, level, diff);	

	if (startGame)
	{
		WORLD.LoadLevel(level,diff);
		VIZ.LoadHUD();
		SOUNDS.LoadSounds();
	}
				
	// main game loop
	while(HAPI->Update())
	{
		
		if (exitGame)
		{
			HAPI->Close();
		}
		else if (startGame)
		{
			WORLD.RenderWorld();
			VIZ.DrawHUD();
			
			DWORD timeNow = HAPI->GetTime();
			if (timeNow - lastCheck >= kDelay)
			{
				HAPI->SetShowFPS(showFPS);
				HAPI->GetKeyboardData(&keyData);				

				if (keyData.scanCode[HK_UP] || keyData.scanCode['W'])
					playerY-=2;
				if (keyData.scanCode[HK_DOWN] || keyData.scanCode['S'])
					playerY+=2;
				if (keyData.scanCode[HK_LEFT] || keyData.scanCode['A'])
					playerX-=2;
				if (keyData.scanCode[HK_RIGHT] || keyData.scanCode['D'])
					playerX+=2;
				if (keyData.scanCode[HK_SPACE] || keyData.scanCode[HK_RCONTROL])
					playerFire = true;
				if (keyData.scanCode['I'])
				{
					if (godMode)
					{
						godMode = false;
						HAPI->UserMessage("God mode disabled", "Debug");
					}
					else
					{
						godMode = true;
						HAPI->UserMessage("God mode enabled", "Debug");
					}
				}
				if (keyData.scanCode['F'])
				{
					if (showFPS)
					{
						showFPS = false;
						HAPI->UserMessage("FPS display off", "Debug");
					}
					else
					{
						showFPS = true;
						HAPI->UserMessage("FPS display on", "Debug");
					}
				}
				enemyRand = rand()%10;
				if (enemyRand == 0 || keyData.scanCode['T'])
					enemyFire = true;
				else
					enemyFire = false;

				WORLD.UpdateWorld(playerX, playerY, playerFire, enemyFire, godMode, gameOver, win);
				WORLD.CheckCollisions();
				
				lastCheck = timeNow;
				playerFire = false;
				enemyFire = false;

				if (keyData.scanCode[HK_ESCAPE])
				{
					SOUNDS.StopStreamed();
					HAPI->Close();
				}
			}
			
			if (gameOver)
			{
				VIZ.DrawMenu(4);
				HAPI->GetKeyboardData(&keyData);
				if (keyData.scanCode[HK_SPACE])
				{
					SOUNDS.StopStreamed();
					HAPI->Close();
				}
			}

			if (win)
			{
				VIZ.DrawMenu(5);
				HAPI->GetKeyboardData(&keyData);
				if (keyData.scanCode[HK_SPACE])
				{
					SOUNDS.StopStreamed();
					HAPI->Close();
				}
			}
		}
	}
	SOUNDS.DeleteInstance();
	WORLD.DeleteInstance();
	VIZ.DeleteInstance();
}

void Menu(bool &s, bool &e, int &l, int &d)
{
	int choice = 0;
	while (HAPI->Update())
	{
		HAPI_TKeyboardData menuData;

		VIZ.DrawMenu(choice);
		if (choice == 2)
		{
			HAPI->UserMessage("This feature is currently disabled.", "Debug");
			choice = 0;
			//d = DifficultyChooser();
		}
		if (choice == 3)
		{
			HAPI->UserMessage("This feature is currently disabled.", "Debug");
			choice = 0;
			//l = LevelChooser();
		}

		HAPI->GetKeyboardData(&menuData);
		if (menuData.scanCode['S'])
		{
			s = true;
			return;
		}
		if (menuData.scanCode['I'])
			choice = 1;
		if (menuData.scanCode['D'])
			choice = 2;
		if (menuData.scanCode['W'])
			choice = 3;
		if (menuData.scanCode['X'])
			choice = 6;
		if (menuData.scanCode[HK_SPACE])
			choice = 0;
		if (menuData.scanCode[HK_RETURN])
		{
			SOUNDS.StopStreamed();
			HAPI->Close();
		}
	}
}

int DifficultyChooser()
{	
	HAPI_TKeyboardData diffData;
	HAPI->GetKeyboardData(&diffData);
	if (diffData.scanCode['1'] || diffData.scanCode[HK_NUMPAD1])
	{
		HAPI->UserMessage("Difficultly level 1 chosen.", "Difficulty");
		return 1;
	}
	if (diffData.scanCode['2'] || diffData.scanCode[HK_NUMPAD2])
	{
		HAPI->UserMessage("Difficultly level 2 chosen.", "Difficulty");
		return 2;
	}
	if (diffData.scanCode['3'] || diffData.scanCode[HK_NUMPAD3])
	{
		HAPI->UserMessage("Difficultly level 3 chosen.", "Difficulty");
		return 3;
	}
	if (diffData.scanCode['4'] || diffData.scanCode[HK_NUMPAD4])
	{
		HAPI->UserMessage("Difficultly level 4 chosen.", "Difficulty");
		return 4;
	}
	if (diffData.scanCode['5'] || diffData.scanCode[HK_NUMPAD5])
	{
		HAPI->UserMessage("Difficultly level 5 chosen.", "Difficulty");
		return 5;
	}
	else
		return 1;
}

int LevelChooser()
{
	HAPI_TKeyboardData levelData;
	HAPI->GetKeyboardData(&levelData);
	if (levelData.scanCode['1'] || levelData.scanCode[HK_NUMPAD1])
	{
		HAPI->UserMessage("Level 1 chosen.", "Level");
		return 1;
	}
	if (levelData.scanCode['2'] || levelData.scanCode[HK_NUMPAD2])
	{
		HAPI->UserMessage("Level 2 chosen.", "Level");
		return 2;
	}
	if (levelData.scanCode['3'] || levelData.scanCode[HK_NUMPAD3])
	{
		HAPI->UserMessage("Level 3 chosen.", "Level");
		return 3;
	}
	if (levelData.scanCode['4'] || levelData.scanCode[HK_NUMPAD4])
	{
		HAPI->UserMessage("Level 4 chosen.", "Level");
		return 4;
	}
	if (levelData.scanCode['5'] || levelData.scanCode[HK_NUMPAD5])
	{
		HAPI->UserMessage("Level 5 chosen.", "Level");
		return 5;
	}
	else
		return 1;
}