using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;


namespace GS2_ICA
{
    public class CCamera
    {
        public CCamera()
        {
        }

        // fields
        Vector3 position;
        Vector3 rotation;
        Vector3 up;
        Vector3 right;
        Vector3 look;
        Matrix viewMatrix;
        float rotationSpeed;

        // properties
        public Vector3 Position
        {
            get { return position; }
            set { position = value; }
        }

        public Vector3 Rotation
        {
            get { return rotation; }
            set { rotation = value; }
        }

        public Vector3 Up
        {
            get { return up; }
            private set { up = value; }
        }

        public Vector3 Right
        {
            get { return right; }
            private set { right = value; }
        }

        public Vector3 Look
        {
            get { return look; }
            private set { look = value; }
        }

        public Matrix ViewMatrix
        {
            get { return viewMatrix; }
            private set { viewMatrix = value; }
        }

        //constructor
        public void Initialize()
        {
            position = new Vector3(0f, 4f, -12f);
            rotation = Vector3.Zero;
            up = Vector3.Up;
            look = Vector3.Backward;
            right = Vector3.Right;
            viewMatrix = Matrix.Identity;
            rotationSpeed = 0.5f;
        }

        //methods
        public enum ECameraRotations
        {
            eYawLeft,
            eYawRight,
            ePitchUp,
            ePitchDown,
            eRollClockwise,
            eRollAnticlockwise
        };

        public void RotateCamera(ECameraRotations rot, float angle)
        {
            switch (rot)
            {
                case ECameraRotations.eYawLeft:
                    RotateAroundY(angle);
                    break;
                case ECameraRotations.eYawRight:
                    RotateAroundY(-angle);
                    break;
                case ECameraRotations.ePitchUp:
                    RotateAroundX(angle);
                    break;
                case ECameraRotations.ePitchDown:
                    RotateAroundX(-angle);
                    break;
                case ECameraRotations.eRollClockwise:
                    RotateAroundZ(angle);
                    break;
                case ECameraRotations.eRollAnticlockwise:
                    RotateAroundZ(-angle);
                    break;
            }
            CalculateViewMatrix();
        }

        private void RotateAroundY(float angle)
        {
            rotation.Y += angle;
            if (rotation.Y > Math.PI * 2)
                rotation.Y -= MathHelper.Pi * 2;
            else if (rotation.Y < 0)
                rotation.Y += MathHelper.Pi * 2;
        }

        private void RotateAroundX(float angle)
        {
            rotation.X += angle;
            if (rotation.X > Math.PI * 2)
                rotation.X -= MathHelper.Pi * 2;
            else if (rotation.X < 0)
                rotation.X += MathHelper.Pi * 2;
        }

        private void RotateAroundZ(float angle)
        {
            rotation.Z += angle;
            if (rotation.Z > Math.PI * 2)
                rotation.Z -= MathHelper.Pi * 2;
            else if (rotation.Z < 0)
                rotation.Z += MathHelper.Pi * 2;
        }

        public enum ECameraMovements
        {
            eMoveRight,
            eMoveLeft,
            eMoveForward,
            eMoveBackward,
            eMoveUp,
            eMoveDown,
        };

        public void MoveCamera(ECameraMovements mov, float distance, float speed)
        {
            switch (mov)
            {
                case ECameraMovements.eMoveRight:
                    position += right * (distance / speed);
                    break;
                case ECameraMovements.eMoveLeft:
                    position -= right * (distance / speed);
                    break;
                case ECameraMovements.eMoveForward:
                    position += look * (distance / speed);
                    break;
                case ECameraMovements.eMoveBackward:
                    position -= look * (distance / speed);
                    break;
                case ECameraMovements.eMoveUp:
                    position += up * (distance / speed);
                    break;
                case ECameraMovements.eMoveDown:
                    position -= up * (distance / speed);
                    break;
            }
            CalculateViewMatrix();
        }

        public Matrix CalculateViewMatrix()
        {
            Matrix rollMatrix = Matrix.CreateFromAxisAngle(look, rotation.Z);
            up = Vector3.Transform(up, rollMatrix);
            right = Vector3.Transform(right, rollMatrix);

            Matrix yawMatrix = Matrix.CreateFromAxisAngle(up, rotation.Y);
            look = Vector3.Transform(look, yawMatrix);
            right = Vector3.Transform(right, yawMatrix);

            Matrix pitchMatrix = Matrix.CreateFromAxisAngle(right, rotation.X);
            look = Vector3.Transform(look, pitchMatrix);
            up = Vector3.Transform(up, pitchMatrix);

            Vector3 target = position + look;

            viewMatrix = Matrix.CreateLookAt(position, target, up);

            return viewMatrix;
        }
    }
}