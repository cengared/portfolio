﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    abstract class CGfxEntity
    {
        // constructor
        protected CGfxEntity()
        { }

        // fields
        protected Matrix viewMatrix;
        protected Matrix worldMatrix;
        protected Matrix scaleMatrix;
        protected Matrix rotationMatrix;
        protected Matrix translationMatrix;
        protected Matrix projectionMatrix;
        protected float aspect;
        protected BoundingBox boundingBox;
        protected BoundingSphere boundingSphere;
        protected Vector3[] obb;

        // virtual methods
        public virtual void Load(string name, ContentManager content)
        { }

        public virtual void Update(Vector3 position, Vector3 rotation, float scale, CCamera cam)
        { }

        public virtual void Render(GameTime gameTime, GraphicsDevice graphicsDevice)
        { }

        public void ConvertBoundingBox()
        {
            obb = new Vector3[8];
            boundingBox.GetCorners(obb);
            Vector3.Transform(obb, ref worldMatrix, obb);
        }

        public BoundingBox BoundingBox
        {
            get { return BoundingBox.CreateFromPoints(obb); }
        }

        public BoundingSphere BoundingSphere
        {
            get { return boundingSphere.Transform(worldMatrix); }
        }
    }
}
