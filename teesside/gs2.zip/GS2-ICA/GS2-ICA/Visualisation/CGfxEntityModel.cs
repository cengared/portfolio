﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    class CGfxEntityModel : CGfxEntity
    {
        // constructors
        public CGfxEntityModel()
        {
            worldMatrix = Matrix.Identity;
            aspect = CVisualisation.Instance.Aspect;
            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect, 1, 1000);
       }

        // fields
        protected Model model;
        protected BoundingBox modelBoundingBox;
        protected BoundingSphere modelBoundingSphere;

        // methods
        public override void Load(string name, ContentManager content)
        {
            model = content.Load<Model>(name);
            CalculateBoundingBox();
        }

        public override void Update(Vector3 position, Vector3 rotation, float scale, CCamera cam)
        {
            translationMatrix = Matrix.CreateTranslation(position);
            rotationMatrix = Matrix.CreateFromYawPitchRoll(MathHelper.ToRadians(rotation.Y), 
                MathHelper.ToRadians(rotation.X), MathHelper.ToRadians(rotation.Z));
            scaleMatrix = Matrix.CreateScale(scale);
            viewMatrix = cam.CalculateViewMatrix();
            worldMatrix = scaleMatrix * rotationMatrix * translationMatrix;
        }

        public override void Render(GameTime gameTime, GraphicsDevice graphicsDevice)
        {
            Matrix[] transforms = new Matrix[model.Bones.Count];
   
            model.CopyAbsoluteBoneTransformsTo(transforms);

            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.Projection = projectionMatrix;
                    effect.View = viewMatrix;
                    effect.World = transforms[mesh.ParentBone.Index] * worldMatrix;   
                }
                mesh.Draw();
                
            }
        }

        public void CalculateBoundingBox()
        {
            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);

            foreach (ModelMesh mesh in model.Meshes)
            {
                // create bounding sphere
                modelBoundingSphere = BoundingSphere.CreateMerged(base.boundingSphere, mesh.BoundingSphere);

                // original code for getting min & max vectors from mesh assuming all models are made of VertexPositionNormalTexture
                // vertices - code didn't work anyway, error saying array is not the correct size for the amount of data requested.
                /*
                VertexPositionNormalTexture[] vertices = new VertexPositionNormalTexture[mesh.VertexBuffer.SizeInBytes / mesh.MeshParts[0].VertexStride];
                mesh.VertexBuffer.GetData<VertexPositionNormalTexture>(vertices);

                Vector3 min = vertices[0].Position;
                Vector3 max = vertices[0].Position;

                for (int i = 1; i < vertices.Length; i++)
                {
                    min = Vector3.Min(min, vertices[i].Position);
                    max = Vector3.Max(max, vertices[i].Position);
                }
                */

                float[] vbData = new float[mesh.VertexBuffer.SizeInBytes / sizeof(float)];
                mesh.VertexBuffer.GetData<float>(vbData);

                Vector3 min = new Vector3(vbData[0], vbData[1], vbData[2]);
                Vector3 max = min;

                for (int i = 0; i < mesh.VertexBuffer.SizeInBytes / sizeof(float); i += mesh.MeshParts[0].VertexStride / sizeof(float))
                {
                    Vector3 pos = new Vector3(vbData[i], vbData[i + 1], vbData[i + 2]);
                    min = Vector3.Min(min, pos);
                    max = Vector3.Max(max, pos);
                }

                min = Vector3.Transform(min, transforms[mesh.ParentBone.Index]);
                max = Vector3.Transform(max, transforms[mesh.ParentBone.Index]);

                modelBoundingBox.Min = Vector3.Min(base.boundingBox.Min, min);
                modelBoundingBox.Max = Vector3.Max(base.boundingBox.Max, max);
            }
            boundingSphere = modelBoundingSphere;
            boundingBox = modelBoundingBox;
        }
    }
}
