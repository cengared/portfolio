﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    class CGfxEntitySkybox : CGfxEntityModel
    {
        // constructors
        public CGfxEntitySkybox()
        {
            worldMatrix = Matrix.Identity;
            aspect = CVisualisation.Instance.Aspect; 
            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect, 1, 1000);
        }

        // methods
        public override void Load(string name, ContentManager content)
        {
            model = content.Load<Model>(name);
        }

        public override void Update(Vector3 position, Vector3 rotation, float scale, CCamera cam)
        {
            translationMatrix = Matrix.CreateTranslation(position);
            rotationMatrix = Matrix.CreateFromYawPitchRoll(MathHelper.ToRadians(rotation.Y),
                MathHelper.ToRadians(rotation.X), MathHelper.ToRadians(rotation.Z));
            scaleMatrix = Matrix.CreateScale(scale);
            
            viewMatrix = cam.CalculateViewMatrix();
            viewMatrix.M41 = 0.0f;
            viewMatrix.M42 = -0.075f;
            viewMatrix.M43 = 0.0f;

            worldMatrix = Matrix.Identity;
        }

        public override void Render(GameTime gameTime, GraphicsDevice graphicsDevice)
        {
            graphicsDevice.RenderState.DepthBufferWriteEnable = false;
            graphicsDevice.RenderState.DepthBufferEnable = false;
            graphicsDevice.SamplerStates[0].AddressU = TextureAddressMode.Clamp;
            graphicsDevice.SamplerStates[0].AddressV = TextureAddressMode.Clamp;

            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);

            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.Projection = projectionMatrix;
                    effect.View = viewMatrix;
                    effect.World = transforms[mesh.ParentBone.Index] * worldMatrix;
                }
                mesh.Draw();
            }

            graphicsDevice.RenderState.DepthBufferWriteEnable = true;
            graphicsDevice.RenderState.DepthBufferEnable = true;
            graphicsDevice.SamplerStates[0].AddressU = TextureAddressMode.Wrap;
            graphicsDevice.SamplerStates[0].AddressV = TextureAddressMode.Wrap;
        }
    }
}
