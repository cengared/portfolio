﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;


namespace GS2_ICA
{
    class CGfxEntityTerrain : CGfxEntity
    {
        // constructor
        public CGfxEntityTerrain()
        {
            worldMatrix = Matrix.Identity;
            aspect = CVisualisation.Instance.Aspect;
            projectionMatrix = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect, 1, 10000);
        }

        // fields
        VertexPositionNormalTexture[] vertices;
        int[] indices;
        int numVerticesHigh;
        int numVerticesWide;
        int numVertices;
        int numTrianglesHigh;
        int numTrianglesWide;
        int numTriangles;
        int startXPosition;
        int startZPosition;
        Texture2D terrain;
        Texture2D heightMap;
        float yPos;
        Color[] colours;
        int cellWidth;
        int cellHeight;
        float sum;
        int bumpiness;
        IndexBuffer indexBuffer;
        VertexBuffer vertexBuffer;
        VertexDeclaration vertexDeclaration;
        
        
        // methods
        public override void Load(string name, ContentManager content)
        {
            terrain = content.Load<Texture2D>(name);
            heightMap = content.Load<Texture2D>(@"Sprites\Textures\bleak-heightmap");
            colours = new Color[heightMap.Width * heightMap.Height];
            heightMap.GetData<Color>(colours);
            bumpiness = 100;
            CreateTerrain(1024, 1024, 256, 256);          
        }

        public override void Update(Vector3 position, Vector3 rotation, float scale, CCamera cam)
        {
            viewMatrix = cam.CalculateViewMatrix();
        }

        public override void Render(GameTime gameTime, GraphicsDevice graphicsDevice)
        {
            vertexDeclaration = new VertexDeclaration(graphicsDevice, VertexPositionNormalTexture.VertexElements);
            
            BasicEffect effect = new BasicEffect(graphicsDevice, null);
            effect.World = worldMatrix;
            effect.View = viewMatrix;
            effect.Projection = projectionMatrix;
            effect.TextureEnabled = true;
            effect.Texture = terrain;

            effect.Begin();
            foreach (EffectPass pass in effect.CurrentTechnique.Passes)
            {
                pass.Begin();
                graphicsDevice.VertexDeclaration = vertexDeclaration;
                graphicsDevice.Vertices[0].SetSource(vertexBuffer, 0, VertexPositionNormalTexture.SizeInBytes);
                graphicsDevice.Indices = indexBuffer;
                graphicsDevice.DrawIndexedPrimitives(PrimitiveType.TriangleList, 0, 0, vertices.Length, 0, indices.Length / 3);
                pass.End();
            }
            effect.End();
        }

        public void CreateTerrain(int worldWidth, int worldHeight, int numCellsWide, int numCellsHigh)
        {
            numVerticesWide = numCellsWide + 1;
            numVerticesHigh = numCellsHigh + 1;
            numVertices = numVerticesWide * numVerticesHigh;

            numTrianglesWide = numCellsWide * 2;
            numTrianglesHigh = numCellsHigh;
            numTriangles = numTrianglesWide * numTrianglesHigh;

            indices = new int[numTriangles * 3];
            vertices = new VertexPositionNormalTexture[numVertices];

            startZPosition = -worldHeight / 2;
            startXPosition = -worldWidth / 2;

            cellWidth = worldWidth / numCellsWide;
            cellHeight = worldHeight / numCellsHigh;

            CreateVerticies(worldWidth, worldHeight, numCellsWide, numCellsHigh);
            CreateTriangles(numCellsHigh, numCellsWide);
        }

        public void CreateVerticies(int worldWidth, int worldHeight, int numCellsWide, int numCellsHigh)
        {
            int count = 0;
            int colCount = 0;
            int worldZPosition = startZPosition;
            for (int y = 0; y < numVerticesHigh; y++)
            {
                int worldXPosition = startXPosition;
                for (int x = 0; x < numVerticesWide; x++)
                {
                    for (int i = cellHeight * y; i < cellHeight + (cellHeight * y); i++)
                    {
                        for (int j = cellWidth * x; j < cellWidth + (cellWidth * x); j++)
                        {
                            colCount = j + (i * heightMap.Height);
                            if (colCount < colours.Length)
                                sum += colours[colCount].R;
                        }
                    }
                    yPos = ((sum / (cellWidth * cellHeight)) / 255) * bumpiness;
                    vertices[count].Position = new Vector3(worldXPosition, yPos, worldZPosition);
                    vertices[count].Normal = Vector3.Up;
                    vertices[count].TextureCoordinate.X = (float)x / (numVerticesWide - 1);
                    vertices[count].TextureCoordinate.Y = (float)y / (numVerticesHigh - 1);

                    count++;
                    sum = 0;

                    worldXPosition += cellWidth;
                }
                worldZPosition += cellHeight;
            }

            vertexBuffer = new VertexBuffer(CVisualisation.Instance.GraphicsDevice, VertexPositionNormalTexture.SizeInBytes * vertices.Length, BufferUsage.WriteOnly);
            vertexBuffer.SetData(vertices);
        }

        public void CreateTriangles(int numCellsHigh, int numCellsWide)
        {
            int index = 0;
            int startVertex = 0;
            for (int cellY = 0; cellY < numCellsHigh; cellY++)
            {
                for (int cellX = 0; cellX < numCellsWide; cellX++)
                {
                    indices[index] = startVertex + 0;
                    indices[index + 1] = startVertex + 1;
                    indices[index + 2] = startVertex + numVerticesWide;

                    index += 3;

                    indices[index] = startVertex + 1;
                    indices[index + 1] = startVertex + numVerticesWide + 1;
                    indices[index + 2] = startVertex + numVerticesWide;

                    index += 3;

                    startVertex++;
                }
                startVertex++;
            }

            indexBuffer = new IndexBuffer(CVisualisation.Instance.GraphicsDevice, typeof(int), indices.Length ,BufferUsage.WriteOnly);
            indexBuffer.SetData(indices);
        }

    }
}
