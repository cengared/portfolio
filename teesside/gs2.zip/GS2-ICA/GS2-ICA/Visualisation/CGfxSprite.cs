﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    abstract class CGfxSprite
    {
        // constructor
        protected CGfxSprite()
        { }

        // fields
        protected Color colour;
        protected Vector2 screenPos;
        protected bool drawThis;
        
        // virtual methods
        public virtual void Load(string name, ContentManager contentManager)
        { }

        public virtual void Load(string name, ContentManager contentManager, string t)
        { }

        public virtual void Update(Vector2 newPos)
        { }

        public virtual void Update(Vector2 newPos, string newtext)
        { }

        public virtual void Render(SpriteBatch spriteBatch)
        { }

        public virtual void Activate(bool activate)
        { }
    }
}
