﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    class CGfxSpriteFont : CGfxSprite
    {
        // constructor
        public CGfxSpriteFont()
        {
            colour = Color.Red;
            screenPos = new Vector2(0, 0);
            drawThis = false;
        }

        // fields
        SpriteFont font;
        string text;
        
        // methods
        public override void Load(string name, ContentManager content, string t)
        {
            font = content.Load<SpriteFont>(name);
            text = t;
        }

        public override void Update(Vector2 newPos, string newText)
        {
            screenPos = newPos;
            text = newText;
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            if (drawThis)
                spriteBatch.DrawString(font, text, screenPos, colour);
        }

        public override void Activate(bool activate)
        {
            drawThis = activate;
        }
    }
}
