﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GS2_ICA
{
    class CGfxSpriteTexture : CGfxSprite
    {
        // constructor
        public CGfxSpriteTexture()
        {
            colour = Color.White;
            screenPos = new Vector2(100, 0);
            drawThis = false;
        }

        // fields
        Texture2D texture;

        // methods
        public override void Load(string name, ContentManager content)
        {
            texture = content.Load<Texture2D>(name);
        }

        public override void Update(Vector2 newPos)
        {
            screenPos = newPos;
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            if (drawThis)
                spriteBatch.Draw(texture, screenPos, colour);
        }

        public override void Activate(bool activate)
        {
            drawThis = activate;
        }
    }
}
