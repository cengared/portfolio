using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace GS2_ICA
{
    public class CVisualisation
    {
        // making class a singleton
        static readonly CVisualisation instance = new CVisualisation();

        static CVisualisation()
        {
        }

        CVisualisation()
        {
        }

        public static CVisualisation Instance
        {
            get { return instance; }
        }

        // fields
        GraphicsDevice graphicsDevice;
        ContentManager contentManager;
        List<CGfxEntity> gfxEntityList;
        List<CGfxSprite> spriteEntityList;
        CCamera camera;
        float aspect;
        int gfxEntityCount;
        int spriteEntityCount;
        string fontName;


        // properties
        public GraphicsDevice GraphicsDevice
        {
            get { return graphicsDevice; }
        }

        public ContentManager VisContentManager
        {
            get { return contentManager; }
        }
          
        // methods
        public void Initialize(ContentManager cm, GraphicsDevice gDev, float a)
        {
            contentManager = cm;
            graphicsDevice = gDev;
            gfxEntityList = new List<CGfxEntity>();
            spriteEntityList = new List<CGfxSprite>();
            camera = new CCamera();
            camera.Initialize();
            aspect = a;
            gfxEntityCount = 0;
            spriteEntityCount = 0;
            fontName = @"Sprites\Fonts\SpriteFont";
        }

        public void LoadContent()
        {
            // load entities

            // skybox
            gfxEntityList.Add(new CGfxEntitySkybox());
            gfxEntityList[gfxEntityCount].Load(@"Models\Skybox\skybox", contentManager);
            // terrain
            gfxEntityCount++;
            gfxEntityList.Add(new CGfxEntityTerrain());
            gfxEntityList[gfxEntityCount].Load(@"Sprites\Textures\bleak", contentManager);
            // airplane model (player)
            gfxEntityCount++;
            gfxEntityList.Add(new CGfxEntityModel());
            gfxEntityList[gfxEntityCount].Load(@"Models\Airplane\airplane2", contentManager);
            // obelisk model
            for (int i = 0; i < 5; i++)
            {
                gfxEntityCount++;
                gfxEntityList.Add(new CGfxEntityModel());
                gfxEntityList[gfxEntityCount].Load(@"Models\Obelisk\obelisk1", contentManager);
            }
            
            // load sprites

            // frame rate text
            spriteEntityList.Add(new CGfxSpriteFont());
            spriteEntityList[spriteEntityCount].Load(fontName, contentManager, "FPS:");
            // 2D texture, used for testing
            spriteEntityCount++;
            spriteEntityList.Add(new CGfxSpriteTexture());
            spriteEntityList[spriteEntityCount].Load(@"Sprites\Textures\player1", contentManager);
            // compass text
            spriteEntityCount++;
            spriteEntityList.Add(new CGfxSpriteFont());
            spriteEntityList[spriteEntityCount].Load(fontName, contentManager, "COMPASS");
            CUI.Instance.ActivateCompass();
            // collision test text
            spriteEntityCount++;
            spriteEntityList.Add(new CGfxSpriteFont());
            spriteEntityList[spriteEntityCount].Load(fontName, contentManager, "COLLISION TEST TEXT");
        }

        public void Update(GameTime gameTime, int id, Vector3 newPosition, Vector3 newRotation, float newScale)
        {
            gfxEntityList[id].Update(newPosition, newRotation, newScale, camera);
            //gfxEntityList[CWorld.Instance.PlayerID].Animate = true;
        }

        public void Update(GameTime gameTime, int id, Vector2 newPosition, string newText)
        {
            spriteEntityList[id].Update(newPosition, newText);
        }

        public void ClearScreen()
        {
            graphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, Color.SkyBlue, 1.0f, 0);
        }

        public void Draw(GameTime gameTime, int id)
        {
            gfxEntityList[id].Render(gameTime, graphicsDevice);
        }

        public void DrawSprite(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred, SaveStateMode.SaveState);
            foreach (CGfxSprite sprite in spriteEntityList)
                sprite.Render(spriteBatch);
            spriteBatch.End();
        }

        public void ActivateSprite(int spriteID, bool activate)
        {
            spriteEntityList[spriteID].Activate(activate);
        }

        // association
        internal CGfxEntity CGfxEntity
        {
            get { return CGfxEntity; }
        }

        public CCamera CCamera
        {
            get { return camera; }
        }

        // properties
        public float Aspect
        {
            get { return aspect; }
        }

        public BoundingBox GetBoundingBox(int id)
        {
            gfxEntityList[id].ConvertBoundingBox();
            return gfxEntityList[id].BoundingBox;
        }

        public BoundingSphere GetBoundingSphere(int id)
        {
            return gfxEntityList[id].BoundingSphere;
        }
    }
}




