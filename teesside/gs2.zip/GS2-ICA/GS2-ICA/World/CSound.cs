﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GS2_ICA
{
    public class CSound
    {
        // constructor
        public CSound()
        {
        }

        // fields
        SoundEffect soundEffect;
        SoundEffectInstance soundInstance;

        public SoundEffectInstance SoundInstance
        {
            get { return soundInstance; }
            set { soundInstance = value; }
        }

        // methods
        public void Load(string name, ContentManager content)
        {
            soundEffect = content.Load<SoundEffect>(name);
        }

        public void Play()
        {
            soundEffect.Play();
        }

        public void Play(float volume, float pitch, float pan, bool loop)
        {
            soundEffect.Play(volume, pitch, pan,loop);
        }
    }
}
