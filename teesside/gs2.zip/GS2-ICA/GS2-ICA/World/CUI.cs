﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Input;

namespace GS2_ICA
{
    public class CUI
    {
        // making class a singleton
        static readonly CUI instance = new CUI();

        static CUI()
        {
        }

        CUI()
        {
        }

        public static CUI Instance
        {
            get { return instance; }
        }

        // fields
        #region Keyboard control fields
        Keys keyForward;
        Keys keyBackward;
        Keys keyLeft;
        Keys keyRight;
        Keys keyUp;
        Keys keyDown;
        Keys keyYawLeft;
        Keys keyYawRight;
        Keys keyPitchUp;
        Keys keyPitchDown;
        Keys keyRollClockwise;
        Keys keyRollAnticlockwise;
        Keys keyFpsOn;
        Keys keyFpsOff;
        Keys keyCompassOn;
        Keys keyCompassOff;
        Keys keyCollisionTextOn;
        Keys keyCollisionTextOff;
        #endregion

        #region Gamepad control fields
        Buttons padForward;
        Buttons padBackward;
        Buttons padLeft;
        Buttons padRight;
        Buttons padUp;
        Buttons padDown;
        Buttons padYawLeft;
        Buttons padYawRight;
        Buttons padPitchUp;
        Buttons padPitchDown;
        Buttons padRollClockwise;
        Buttons padRollAnticlockwise;
        Buttons padFpsOn;
        Buttons padFpsOff;
        Buttons padCompassOn;
        Buttons padCompassOff;
        Buttons padCollisionTextOn;
        Buttons padCollisionTextOff;
        #endregion
        
        KeyboardState keyboard;
        GamePadState gamePad;
        MouseState mouse;
        int playerID;
        float playerSpeed;
        float distance;
        float angle;
        float delta;
        int windowWidth;
        int windowHeight;
        
        // methods
        public void Initialize(int screenWidth, int screenHeight)
        {
            SetKeyboardControls();
            SetGamePadControls();
            distance = 1f;
            angle = MathHelper.ToRadians(10f);
            playerID = CWorld.Instance.PlayerID;
            windowWidth = screenWidth;
            windowHeight = screenHeight;
        }

        public void Update(CCamera camera, GameTime gameTime)
        {
            delta = (float)gameTime.ElapsedGameTime.TotalSeconds;
            keyboard = Keyboard.GetState();
            gamePad = GamePad.GetState(PlayerIndex.One);
            mouse = Mouse.GetState();

            playerID = CWorld.Instance.PlayerID;
            playerSpeed = CWorld.Instance.PlayerSpeed;

            // movement controls
            if (keyboard.IsKeyDown(keyForward) || gamePad.IsButtonDown(padForward))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveForward, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveForward, distance, playerSpeed);
            }
            if (keyboard.IsKeyDown(keyBackward) || gamePad.IsButtonDown(padBackward))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveBackward, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveBackward, distance, playerSpeed);
            }
            if (keyboard.IsKeyDown(keyLeft) || gamePad.IsButtonDown(padLeft))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveLeft, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveLeft, -distance, playerSpeed);
            }
            if (keyboard.IsKeyDown(keyRight) || gamePad.IsButtonDown(padRight))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveRight, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveRight, -distance, playerSpeed);
            }
            if (keyboard.IsKeyDown(keyUp) || gamePad.IsButtonDown(padUp))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveUp, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveUp, distance, playerSpeed);
            }
            if (keyboard.IsKeyDown(keyDown) || gamePad.IsButtonDown(padDown))
            {
                CWorld.Instance.MoveEntity(CWorld.EMove.eMoveDown, distance, playerID);
                camera.MoveCamera(CCamera.ECameraMovements.eMoveDown, distance, playerSpeed);
            }

            // rotation controls
            // camera rotations commented out because they're not working correctly
            if (keyboard.IsKeyDown(keyYawLeft) || gamePad.IsButtonDown(padYawLeft))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.eYawLeft, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.eYawLeft, angle);
            }
            if (keyboard.IsKeyDown(keyYawRight) || gamePad.IsButtonDown(padYawRight))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.eYawRight, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.eYawRight, angle);
            }
            if (keyboard.IsKeyDown(keyPitchUp) || gamePad.IsButtonDown(padPitchUp))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.ePitchUp, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.ePitchUp, angle);
            }
            if (keyboard.IsKeyDown(keyPitchDown) || gamePad.IsButtonDown(padPitchDown))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.ePitchDown, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.ePitchDown, angle);
            }
            if (keyboard.IsKeyDown(keyRollClockwise) || gamePad.IsButtonDown(padRollClockwise))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.eRollClockwise, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.eRollClockwise, angle);
            }
            if (keyboard.IsKeyDown(keyRollAnticlockwise) || gamePad.IsButtonDown(padRollAnticlockwise))
            {
                CWorld.Instance.RotateEntity(CWorld.ERotate.eRollAnticlockwise, angle, playerID);
                //camera.RotateCamera(CCamera.ECameraRotations.eRollAnticlockwise, angle);
            }

            // on screen text controls
            // frame rate
            if (keyboard.IsKeyDown(keyFpsOn) || gamePad.IsButtonDown(padFpsOn))
            {
                CVisualisation.Instance.ActivateSprite(0, true);
                CWorld.Instance.PlaySound(1);
            }
            if (keyboard.IsKeyDown(keyFpsOff) || gamePad.IsButtonDown(padFpsOff))
            {
                CVisualisation.Instance.ActivateSprite(0, false);
                CWorld.Instance.PlaySound(1);
            }
            // compass
            if (keyboard.IsKeyDown(keyCompassOn) || gamePad.IsButtonDown(padCompassOn))
            {
                CVisualisation.Instance.ActivateSprite(2, true);
                CWorld.Instance.PlaySound(1);
            }
            if (keyboard.IsKeyDown(keyCompassOff) || gamePad.IsButtonDown(padCompassOff))
            {
                CVisualisation.Instance.ActivateSprite(2, false);
                CWorld.Instance.PlaySound(1);
            }
            // collision text
            if (keyboard.IsKeyDown(keyCollisionTextOn) || gamePad.IsButtonDown(padCollisionTextOn))
            {
                CVisualisation.Instance.ActivateSprite(3, true);
                CWorld.Instance.PlaySound(1);
            }
            if (keyboard.IsKeyDown(keyCollisionTextOff) || gamePad.IsButtonDown(padCollisionTextOff))
            {
                CVisualisation.Instance.ActivateSprite(3, false);
                CWorld.Instance.PlaySound(1);
            }
        }

        public void ActivateCompass()
        {
            CVisualisation.Instance.ActivateSprite(2, true);
        }

        public void SetKeyboardControls()
        {
            keyForward = Keys.Up;
            keyBackward = Keys.Down;
            keyLeft = Keys.Left;
            keyRight = Keys.Right;
            keyUp = Keys.RightShift;
            keyDown = Keys.RightControl;
            keyYawLeft = Keys.NumPad1;
            keyYawRight = Keys.NumPad3;
            keyPitchUp = Keys.NumPad8;
            keyPitchDown = Keys.NumPad2;
            keyRollClockwise = Keys.NumPad9;
            keyRollAnticlockwise = Keys.NumPad7;
            keyFpsOn = Keys.F;
            keyFpsOff = Keys.G;
            keyCompassOn = Keys.C;
            keyCompassOff = Keys.V;
            keyCollisionTextOn = Keys.OemOpenBrackets;
            keyCollisionTextOff = Keys.OemCloseBrackets;
        }

        public void SetGamePadControls()
        {
            padForward = Buttons.RightTrigger;
            padBackward = Buttons.LeftTrigger;
            padLeft = Buttons.LeftThumbstickLeft;
            padRight = Buttons.LeftThumbstickRight;
            padUp = Buttons.LeftThumbstickUp;
            padDown = Buttons.LeftThumbstickDown;
            padYawLeft = Buttons.RightThumbstickLeft;
            padYawRight = Buttons.RightThumbstickRight;
            padPitchUp = Buttons.RightThumbstickUp;
            padPitchDown = Buttons.RightThumbstickDown;
            padRollClockwise = Buttons.RightShoulder;
            padRollAnticlockwise = Buttons.LeftShoulder;
            padFpsOn = Buttons.DPadLeft;
            padFpsOff = Buttons.DPadRight;
            padCompassOn = Buttons.B;
            padCompassOff = Buttons.X;
            padCollisionTextOn = Buttons.DPadUp;
            padCollisionTextOff = Buttons.DPadDown;
        }

    }
}
