using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;


namespace GS2_ICA
{

    public class CWorld
    {
        // making this class a singleton
        static readonly CWorld instance = new CWorld();

        static CWorld()
        {
        }

        CWorld()
        {

        }

        public static CWorld Instance
        {
            get { return instance; }
        }

        // fields
        List<CWorldEntity> worldEntityList;
        float playerSpeed;
        int playerGraphicID;
        int graphicID;
        int playerID;
        int worldEntityCount;
        string collisionType;
        List<CSound> soundEffectList;
        SoundEffectInstance propSound;
        SoundEffectInstance beepSound;

        // properties
        public float PlayerSpeed
        {
            get { return playerSpeed; }
        }

        public int PlayerGraphicID
        {
            get { return playerGraphicID; }
        }

        public int PlayerID
        {
            get { return playerID; }
        }

        // methods
        public void Initialize()
        {
            worldEntityList = new List<CWorldEntity>();
            worldEntityCount = 0;
            graphicID = 0;
            collisionType = "NO COLLISION";
            soundEffectList = new List<CSound>();
        }

        public void LoadLevel()
        {
            // create world entities
            // scenery - skybox - non-collidable
            worldEntityList.Add(new CWorldEntityScenery(graphicID, Vector3.Zero, false));
            // scenery - terrain - non-collidable
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, Vector3.Zero, false));
            // player - airplane
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityPlayer(graphicID, new Vector3(0, 2, 0)));
            playerID = worldEntityCount;
            playerSpeed = worldEntityList[PlayerID].Speed;
            playerGraphicID = worldEntityList[PlayerID].GraphicID;
            // scenery - obelisks - collidable
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, new Vector3(50, 0, 20), true));
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, new Vector3(150, 0, 70), true));
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, new Vector3(-20, 0, 200), true));
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, new Vector3(500, 0, 400), true));
            worldEntityCount++;
            graphicID++;
            worldEntityList.Add(new CWorldEntityScenery(graphicID, new Vector3(-200, 0, -420), true));

            // sound
            soundEffectList.Add(new CSound());
            soundEffectList[0].Load(@"Audio\Prop", CVisualisation.Instance.VisContentManager);
            soundEffectList[0].Play(0.3f, 0f, 0f, true);
            soundEffectList.Add(new CSound());
            soundEffectList[1].Load(@"Audio\click", CVisualisation.Instance.VisContentManager);
        }

        public void Update(GameTime gameTime)
        {
            foreach (CWorldEntity entity in worldEntityList)
                entity.Update(gameTime);
            CVisualisation.Instance.Update(gameTime, 2, new Vector2(350, 560), worldEntityList[2].CompassDirection);
            CVisualisation.Instance.Update(gameTime, 3, new Vector2(400, 300), collisionType);
            CollisionCheck();
        }

        public void Draw(GameTime gameTime)
        {
            foreach (CWorldEntity entity in worldEntityList)
                entity.Draw(gameTime);
        }

        public void MoveEntity(EMove move, float distance, int id)
        {
            worldEntityList[id].Move(move, distance);
        }

        public void RotateEntity(ERotate rotate, float angle, int id)
        {
            worldEntityList[id].Rotate(rotate, angle);
        }

        public void CollisionCheck()
        {
            BoundingSphere playerSphere = worldEntityList[PlayerID].CollisionCheckSphere();
            BoundingBox playerBox = worldEntityList[playerID].CollisionCheckBox();
            bool sphereCollision = false;
            bool boxCollision = false;
            foreach (CWorldEntity entity in worldEntityList)
            {
                if (entity.CheckForCollision)
                {
                    BoundingSphere otherSphere = entity.CollisionCheckSphere();
                    sphereCollision = playerSphere.Intersects(otherSphere);
                    if (sphereCollision)
                    {
                        BoundingBox otherBox = entity.CollisionCheckBox();
                        boxCollision = playerBox.Intersects(otherBox);
                        if (boxCollision)
                            collisionType = "BOX COLLISION";
                        else
                            collisionType = "SPHERE COLLISION";
                    }
                    else
                        collisionType = "NO COLLISION";
                }
            }   
        }

        // association
        internal CWorldEntity CWorldEntity
        {
            get { return CWorldEntity; }
        }

        public enum EMove
        {
            eMoveForward,
            eMoveBackward,
            eMoveLeft,
            eMoveRight,
            eMoveUp,
            eMoveDown,
        };

        public enum ERotate
        {
            eYawLeft,
            eYawRight,
            ePitchUp,
            ePitchDown,
            eRollClockwise,
            eRollAnticlockwise,
        };

        public void PlaySound(int soundID)
        {
            soundEffectList[soundID].Play();
        }

        public void PlaySound(int soundID, float volume, float pitch, float pan, bool loop)
        {
            soundEffectList[soundID].Play(volume, pitch, pan, loop);
        }
    }
}