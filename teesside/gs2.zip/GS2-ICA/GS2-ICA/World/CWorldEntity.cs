﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;

namespace GS2_ICA
{
    abstract class CWorldEntity
    {
        // constructor
        public CWorldEntity()
        { }
        
        // fields
        protected Vector3 position;
        protected Vector3 rotation;
        protected float scale;
        protected int graphicID;
        protected float speed;
        protected string compassDirection;
        protected bool checkForCollisions;
        //protected int health;

        // methods
        public virtual void Update(GameTime gameTime)
        { }

        public virtual void Draw(GameTime gameTime)
        { }

        public virtual void Move(CWorld.EMove move, float distance)
        { }

        public virtual void Rotate(CWorld.ERotate rotate, float angle)
        { }

        public virtual void CollisionCheck(BoundingSphere sphere)
        { }

        public virtual void CollisionCheck(BoundingBox box)
        { }

        public BoundingSphere CollisionCheckSphere()
        {
            return CVisualisation.Instance.GetBoundingSphere(graphicID);
        }

        public BoundingBox CollisionCheckBox()
        {
            return CVisualisation.Instance.GetBoundingBox(graphicID);
        }

        public virtual float Speed
        {
            get { return speed; }
        }

        public virtual int GraphicID
        {
            get { return graphicID; }
        }

        public virtual string CompassDirection
        {
            get { return compassDirection; }
        }

        public bool CheckForCollision
        {
            get { return checkForCollisions; }
        }
    }
}
