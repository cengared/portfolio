﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;

namespace GS2_ICA
{
    class CWorldEntityPlayer : CWorldEntity
    {
        // constructor
        public CWorldEntityPlayer(int id, Vector3 startPosition)
        {
            position = startPosition;
            rotation = Vector3.Zero;
            scale = 1f;
            graphicID = id;
            speed = 0.75f;
            compassDirection = "DUE NORTH";
            checkForCollisions = false;
        }

        // methods
        public override void Update(GameTime gameTime)
        {
            CVisualisation.Instance.Update(gameTime, graphicID, position, rotation, scale);
            UpdateCompass();
        }

        public override void Draw(GameTime gameTime)
        {
            CVisualisation.Instance.Draw(gameTime, graphicID);
        }

        public override void Move(CWorld.EMove move, float distance)
        {
            switch (move)
            {
                case CWorld.EMove.eMoveForward:
                    position.Z += distance / speed;
                    break;
                case CWorld.EMove.eMoveBackward:
                    position.Z -= distance / speed;
                    break;
                case CWorld.EMove.eMoveRight:
                    position.X -= distance / speed;
                    break;
                case CWorld.EMove.eMoveLeft:
                    position.X += distance / speed;
                    break;
                case CWorld.EMove.eMoveUp:
                    position.Y += distance / speed;
                    break;
                case CWorld.EMove.eMoveDown:
                    position.Y -= distance / speed;
                    break;
            }
        }

        public override void Rotate(CWorld.ERotate rotate, float angle)
        {
            switch (rotate)
            {
                case CWorld.ERotate.eYawLeft:
                    rotation.Y += angle;
                    break;
                case CWorld.ERotate.eYawRight:
                    rotation.Y -= angle;
                    break;
                case CWorld.ERotate.ePitchUp:
                    rotation.X += angle;
                    break;
                case CWorld.ERotate.ePitchDown:
                    rotation.X -= angle;
                    break;
                case CWorld.ERotate.eRollClockwise:
                    rotation.Z += angle;
                    break;
                case CWorld.ERotate.eRollAnticlockwise:
                    rotation.Z -= angle;
                    break;
            }
        }

        public void UpdateCompass()
        {
            if (rotation.Y < 0)
                rotation.Y += 360;
            if (rotation.Y > 360)
                rotation.Y -= 360;
            if (rotation.Y >= 0 && rotation.Y < 0.5)
                compassDirection = ">DUE NORTH<";
            else if (rotation.Y > 0.4 && rotation.Y < 22.5)
                compassDirection = ">>>>.N.<<<<";
            else if (rotation.Y > 22.4 && rotation.Y < 67.5)
                compassDirection = ">>>>NE<<<<";
            else if (rotation.Y > 67.4 && rotation.Y < 89.5)
                compassDirection = ">>>>.E.<<<<";
            else if (rotation.Y > 89.4 && rotation.Y < 90.5)
                compassDirection = ">DUE EAST<";
            else if (rotation.Y > 90.5 && rotation.Y < 112.5)
                compassDirection = ">>>>.E.<<<<";
            else if (rotation.Y > 112.4 && rotation.Y < 157.5)
                compassDirection = ">>>>SE<<<<";
            else if (rotation.Y > 157.4 && rotation.Y < 179.5)
                compassDirection = ">>>>.S.<<<<";
            else if (rotation.Y > 179.4 && rotation.Y < 180.5)
                compassDirection = ">DUE SOUTH<";
            else if (rotation.Y > 180.5 && rotation.Y < 202.5)
                compassDirection = ">>>>.S.<<<<";
            else if (rotation.Y > 202.4 && rotation.Y < 247.5)
                compassDirection = ">>>>SW<<<<";
            else if (rotation.Y > 247.4 && rotation.Y < 269.5)
                compassDirection = ">>>>.W.<<<<";
            else if (rotation.Y > 269.4 && rotation.Y < 270.5)
                compassDirection = ">DUE WEST<";
            else if (rotation.Y > 270.4 && rotation.Y < 292.5)
                compassDirection = ">>>>.W.<<<<";
            else if (rotation.Y > 292.4 && rotation.Y < 337.5)
                compassDirection = ">>>>NW<<<<";
            else
                compassDirection = ">>>>N<<<<";

        }
    }
}
