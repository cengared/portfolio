﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;

namespace GS2_ICA
{
    class CWorldEntityScenery : CWorldEntity
    {
        // constructor
        public CWorldEntityScenery(int id, Vector3 startPosition, bool collideWith)
        {
            position = startPosition;
            rotation = Vector3.Zero;
            scale = 1f;
            graphicID = id;
            checkForCollisions = collideWith;
        }

        // methods
        public override void Update(GameTime gameTime)
        {
            CVisualisation.Instance.Update(gameTime, graphicID, position, rotation, scale);
        }

        public override void Draw(GameTime gameTime)
        {
            CVisualisation.Instance.Draw(gameTime, graphicID);
        }

        
    }
}
