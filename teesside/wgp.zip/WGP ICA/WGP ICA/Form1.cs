﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WGP_ICA
{
    public partial class Form1 : Form
    {
        CPotluck game;
        string errorTitle;
        string ending;

        public Form1()
        {
            InitializeComponent();
            errorTitle = "Transaction failed";
            diceRollPicBox.Image = imageList1.Images[0];
        }

        // Quit button & File--Exit
        private void quitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // New button & File--New
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            game = new CPotluck();
            this.updateScreen();
            yesterdayText.Text = game.GetYesterdayText();
            locationText.Text = game.GetLocationText();
            placePotsButton.Enabled = true;
            purchaseButton.Enabled = true;
            sellButton.Enabled = true;
            saveButton.Enabled = true;
            saveToolStripMenuItem.Enabled = true;
        }

        // Place Pots button
        private void placePotsButton_Click(object sender, EventArgs e)
        {
            Form2 placePots = new Form2();
            DialogResult dr = placePots.ShowDialog();
            if (dr != DialogResult.OK)
                return;
            else
            {
                game.Location = placePots.Loc;
                locationText.Text = game.GetLocationText();
            }
            rollButton.Enabled = true;
            diceRollPicBox.Enabled = true;
        }

        // Roll Dice button
        private void rollButton_Click(object sender, EventArgs e)
        {
            game.RollDice();
            diceRollPicBox.Image = imageList1.Images[game.DiceRoll];
            placePotsButton.Enabled = false;
            purchaseButton.Enabled = false;
            sellButton.Enabled = false;
            advanceButton.Enabled = true;
            rollButton.Enabled = false;
            diceRollPicBox.Enabled = false;
        }

        // Purchase button
        private void purchaseButton_Click(object sender, EventArgs e)
        {
            Form3 purchase = new Form3(game);
            DialogResult dr = purchase.ShowDialog();
            if (dr != DialogResult.OK)
                return;
            else
            {
                if (game.Buy(purchase.BoatsToBuy, purchase.PotsToBuy))
                    this.updateScreen();
                else
                    MessageBox.Show(game.ErrorMessage, errorTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Sell button
        private void sellButton_Click(object sender, EventArgs e)
        {
            Form4 sell = new Form4(game);
            DialogResult dr = sell.ShowDialog();
            if (dr != DialogResult.OK)
                return;
            else
            {
                if (game.Sell(sell.BoatsToSell, sell.PotsToSell))
                    this.updateScreen();
                else
                    MessageBox.Show(game.ErrorMessage, errorTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Save button & File--Save
        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult saveDR = saveFileDialog1.ShowDialog();
                if (saveDR != DialogResult.OK)
                    return;
                else
                    game.SaveGame(saveFileDialog1.FileName);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Exception thrown", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Load button & File--Load
        private void loadButton_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult openDR = openFileDialog1.ShowDialog();
                if (openDR != DialogResult.OK)
                    return;
                else
                {
                    game = CPotluck.LoadGame(openFileDialog1.FileName);
                    this.updateScreen();
                    yesterdayText.Text = game.GetYesterdayText();
                    locationText.Text = game.GetLocationText();
                    placePotsButton.Enabled = true;
                    purchaseButton.Enabled = true;
                    sellButton.Enabled = true;
                    saveButton.Enabled = true;
                    saveToolStripMenuItem.Enabled = true;
                    diceRollPicBox.Image = imageList1.Images[game.DiceRoll];
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Exception thrown", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Updates text in textboxes
        private void updateScreen()
        {
            dayNumText.Text = Convert.ToString(game.Day);
            cashText.Text = "$"+Convert.ToString(game.Cash);
            boatsNumText.Text = Convert.ToString(game.NumBoats);
            potsNumText.Text = Convert.ToString(game.NumPots);
        }

        // Advance button - moves the game on
        private void advanceButton_Click(object sender, EventArgs e)
        {
            if (game.Day == 10)
            {
                if (game.EndGame())
                    ending = "Congratulations, you have earned enough money to leave the island";
                else
                    ending = "Commiserations, you have not earned enough money to leave the island";
                
                Form6 gameOver = new Form6(game, ending);
                gameOver.ShowDialog();
                game.NumBoats = 0;
                game.NumPots = 0;
                this.updateScreen();
                advanceButton.Enabled = false;
                saveButton.Enabled = false;
                saveToolStripMenuItem.Enabled = false;
            }
            else
            {
                game.CalculateEarnings();
                Form5 status = new Form5(game);
                status.ShowDialog();

                game.Advance();
                this.updateScreen();
                locationText.Text = game.GetLocationText();
                yesterdayText.Text = game.GetYesterdayText();
                placePotsButton.Enabled = true;
                purchaseButton.Enabled = true;
                sellButton.Enabled = true;
                rollButton.Enabled = false;
                diceRollPicBox.Enabled = false;
                advanceButton.Enabled = false;

                if (game.Day == 10)
                {
                    advanceButton.Enabled = true;
                    placePotsButton.Enabled = false;
                    purchaseButton.Enabled = false;
                    sellButton.Enabled = false;
                    diceRollPicBox.Image = imageList1.Images[0];
                }
            }
        }

        // Help--About
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutBox = new AboutBox1();
            aboutBox.ShowDialog();
        }
    }
}
