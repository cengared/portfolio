﻿namespace WGP_ICA
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.harbourButton = new System.Windows.Forms.Button();
            this.seaButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // harbourButton
            // 
            this.harbourButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.harbourButton.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.harbourButton.Location = new System.Drawing.Point(22, 59);
            this.harbourButton.Name = "harbourButton";
            this.harbourButton.Size = new System.Drawing.Size(100, 25);
            this.harbourButton.TabIndex = 0;
            this.harbourButton.Text = "Harbour";
            this.harbourButton.UseVisualStyleBackColor = true;
            this.harbourButton.Click += new System.EventHandler(this.harbourButton_Click);
            // 
            // seaButton
            // 
            this.seaButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.seaButton.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seaButton.Location = new System.Drawing.Point(153, 59);
            this.seaButton.Name = "seaButton";
            this.seaButton.Size = new System.Drawing.Size(100, 25);
            this.seaButton.TabIndex = 1;
            this.seaButton.Text = "Open Sea";
            this.seaButton.UseVisualStyleBackColor = true;
            this.seaButton.Click += new System.EventHandler(this.seaButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose where you wish to place your pots for today:";
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(279, 59);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(100, 25);
            this.cancelButton.TabIndex = 3;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 101);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.seaButton);
            this.Controls.Add(this.harbourButton);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Place Pots";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button harbourButton;
        private System.Windows.Forms.Button seaButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cancelButton;
    }
}