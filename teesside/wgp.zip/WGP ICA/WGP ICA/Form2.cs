﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WGP_ICA
{
    public partial class Form2 : Form
    {
        ELocation loc;

        public Form2()
        {
            InitializeComponent();
            loc = new ELocation();
        }

        private void harbourButton_Click(object sender, EventArgs e)
        {
            Loc = ELocation.eHarbour;
        }

        private void seaButton_Click(object sender, EventArgs e)
        {
            Loc = ELocation.eSea;
        }

        public ELocation Loc
        {
            get { return loc; }
            set { loc = value; }
        }
    }
}
