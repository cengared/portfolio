﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WGP_ICA
{
    public partial class Form3 : Form
    {
        int buyBoats, buyPots;
        int cashAvailable;
        
        public Form3(CPotluck p)
        {
            InitializeComponent();
            buyBoats = 0;
            buyPots = 0;
            cashAvailable = p.Cash;
            cashText.Text = Convert.ToString(cashAvailable);
            boatNumText.Text = Convert.ToString(p.NumBoats);
            potNumText.Text = Convert.ToString(p.NumPots);
        }

        private void purchaseButton_Click(object sender, EventArgs e)
        {
            buyBoats = Convert.ToInt32(buyBoatsTextbox.Text);
            buyPots = Convert.ToInt32(buyPotsTextbox.Text);
        }

        public int BoatsToBuy
        {
            get { return buyBoats; }
        }

        public int PotsToBuy
        {
            get { return buyPots; }
        }

        private void buyBoatsTextbox_Validating(object sender, CancelEventArgs e)
        {
            Regex data = new Regex(@"\d");

            if (!data.IsMatch(((Control)sender).Text))
            {
                MessageBox.Show("Only numerical values allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private void buyPotsTextbox_Validating(object sender, CancelEventArgs e)
        {
            Regex data = new Regex(@"\d");

            if (!data.IsMatch(((Control)sender).Text))
            {
                MessageBox.Show("Only numerical values allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }
    }
}
