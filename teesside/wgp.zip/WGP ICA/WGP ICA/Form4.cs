﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WGP_ICA
{
    public partial class Form4 : Form
    {
        int sellBoats, sellPots;

        public Form4(CPotluck p)
        {
            InitializeComponent();
            sellBoats = 0;
            sellPots = 0;
            cashText.Text = Convert.ToString(p.Cash);
            boatNumText.Text = Convert.ToString(p.NumBoats);
            potNumText.Text = Convert.ToString(p.NumPots);
        }

        private void sellButton_Click(object sender, EventArgs e)
        {
            sellBoats = Convert.ToInt32(sellBoatsTextbox.Text);
            sellPots = Convert.ToInt32(sellPotsTextbox.Text);
        }

        public int BoatsToSell
        {
            get { return sellBoats; }
        }

        public int PotsToSell
        {
            get { return sellPots; }
        }

        private void sellBoatsTextbox_Validating(object sender, CancelEventArgs e)
        {
            Regex data = new Regex(@"\d");

            if (!data.IsMatch(((Control)sender).Text))
            {
                MessageBox.Show("Only numerical values allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private void sellPotsTextbox_Validating(object sender, CancelEventArgs e)
        {
            Regex data = new Regex(@"\d");

            if (!data.IsMatch(((Control)sender).Text))
            {
                MessageBox.Show("Only numerical values allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }


    }
}
