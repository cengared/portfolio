﻿namespace WGP_ICA
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.okButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lostPotsText = new System.Windows.Forms.Label();
            this.todayWeatherText = new System.Windows.Forms.Label();
            this.potLocationText = new System.Windows.Forms.Label();
            this.todayEarningsText = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dayText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.okButton.Location = new System.Drawing.Point(111, 208);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(100, 25);
            this.okButton.TabIndex = 0;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = "Today\'s weather:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "Location of pots:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 14);
            this.label3.TabIndex = 3;
            this.label3.Text = "Amount earned today:";
            // 
            // lostPotsText
            // 
            this.lostPotsText.AutoSize = true;
            this.lostPotsText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lostPotsText.Location = new System.Drawing.Point(12, 173);
            this.lostPotsText.Name = "lostPotsText";
            this.lostPotsText.Size = new System.Drawing.Size(280, 14);
            this.lostPotsText.TabIndex = 4;
            this.lostPotsText.Text = "All pots were lost today due to storm";
            this.lostPotsText.Visible = false;
            // 
            // todayWeatherText
            // 
            this.todayWeatherText.AutoSize = true;
            this.todayWeatherText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todayWeatherText.Location = new System.Drawing.Point(181, 62);
            this.todayWeatherText.Name = "todayWeatherText";
            this.todayWeatherText.Size = new System.Drawing.Size(10, 14);
            this.todayWeatherText.TabIndex = 5;
            this.todayWeatherText.Text = "-";
            // 
            // potLocationText
            // 
            this.potLocationText.AutoSize = true;
            this.potLocationText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.potLocationText.Location = new System.Drawing.Point(181, 96);
            this.potLocationText.Name = "potLocationText";
            this.potLocationText.Size = new System.Drawing.Size(10, 14);
            this.potLocationText.TabIndex = 6;
            this.potLocationText.Text = "-";
            // 
            // todayEarningsText
            // 
            this.todayEarningsText.AutoSize = true;
            this.todayEarningsText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todayEarningsText.Location = new System.Drawing.Point(181, 136);
            this.todayEarningsText.Name = "todayEarningsText";
            this.todayEarningsText.Size = new System.Drawing.Size(10, 14);
            this.todayEarningsText.TabIndex = 7;
            this.todayEarningsText.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(133, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Day:";
            // 
            // dayText
            // 
            this.dayText.AutoSize = true;
            this.dayText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayText.Location = new System.Drawing.Point(181, 28);
            this.dayText.Name = "dayText";
            this.dayText.Size = new System.Drawing.Size(10, 14);
            this.dayText.TabIndex = 9;
            this.dayText.Text = "-";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 248);
            this.Controls.Add(this.dayText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.todayEarningsText);
            this.Controls.Add(this.potLocationText);
            this.Controls.Add(this.todayWeatherText);
            this.Controls.Add(this.lostPotsText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.okButton);
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Summary of Today";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lostPotsText;
        private System.Windows.Forms.Label todayWeatherText;
        private System.Windows.Forms.Label potLocationText;
        private System.Windows.Forms.Label todayEarningsText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label dayText;
    }
}