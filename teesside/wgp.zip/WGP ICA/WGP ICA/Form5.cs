﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WGP_ICA
{
    public partial class Form5 : Form
    {
        public Form5(CPotluck p)
        {
            InitializeComponent();

            dayText.Text = Convert.ToString(p.Day);
            todayWeatherText.Text = p.GetTodayText();
            potLocationText.Text = p.GetLocationText();
            todayEarningsText.Text = "$"+Convert.ToString(p.EarnToday);
            if (p.Today == EWeather.eStorm && p.Location == ELocation.eSea)
                lostPotsText.Visible = true;
        }
    }
}
