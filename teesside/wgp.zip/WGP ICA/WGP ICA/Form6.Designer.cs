﻿namespace WGP_ICA
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cash10Text = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cashSaleText = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cashTotalText = new System.Windows.Forms.Label();
            this.winStateText = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.targetText = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.diffText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cash after 10 days:";
            // 
            // cash10Text
            // 
            this.cash10Text.AutoSize = true;
            this.cash10Text.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cash10Text.Location = new System.Drawing.Point(307, 25);
            this.cash10Text.Name = "cash10Text";
            this.cash10Text.Size = new System.Drawing.Size(10, 14);
            this.cash10Text.TabIndex = 1;
            this.cash10Text.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(68, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cash from sale of equipment:";
            // 
            // cashSaleText
            // 
            this.cashSaleText.AutoSize = true;
            this.cashSaleText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashSaleText.Location = new System.Drawing.Point(307, 59);
            this.cashSaleText.Name = "cashSaleText";
            this.cashSaleText.Size = new System.Drawing.Size(10, 14);
            this.cashSaleText.TabIndex = 3;
            this.cashSaleText.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(142, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 14);
            this.label5.TabIndex = 4;
            this.label5.Text = "Total cash earned:";
            // 
            // cashTotalText
            // 
            this.cashTotalText.AutoSize = true;
            this.cashTotalText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashTotalText.Location = new System.Drawing.Point(307, 92);
            this.cashTotalText.Name = "cashTotalText";
            this.cashTotalText.Size = new System.Drawing.Size(10, 14);
            this.cashTotalText.TabIndex = 5;
            this.cashTotalText.Text = "-";
            // 
            // winStateText
            // 
            this.winStateText.AutoSize = true;
            this.winStateText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winStateText.Location = new System.Drawing.Point(11, 203);
            this.winStateText.Name = "winStateText";
            this.winStateText.Size = new System.Drawing.Size(511, 14);
            this.winStateText.TabIndex = 6;
            this.winStateText.Text = "Commiserations, you have not earned enough money to leave the island";
            this.winStateText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.okButton.Location = new System.Drawing.Point(206, 244);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(100, 25);
            this.okButton.TabIndex = 0;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            // 
            // targetText
            // 
            this.targetText.AutoSize = true;
            this.targetText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.targetText.Location = new System.Drawing.Point(307, 127);
            this.targetText.Name = "targetText";
            this.targetText.Size = new System.Drawing.Size(10, 14);
            this.targetText.TabIndex = 8;
            this.targetText.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(224, 127);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 14);
            this.label9.TabIndex = 9;
            this.label9.Text = "Target:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(193, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 14);
            this.label2.TabIndex = 10;
            this.label2.Text = "Difference:";
            // 
            // diffText
            // 
            this.diffText.AutoSize = true;
            this.diffText.Font = new System.Drawing.Font("Copperplate Gothic Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diffText.Location = new System.Drawing.Point(307, 159);
            this.diffText.Name = "diffText";
            this.diffText.Size = new System.Drawing.Size(10, 14);
            this.diffText.TabIndex = 11;
            this.diffText.Text = "-";
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 281);
            this.Controls.Add(this.diffText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.targetText);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.winStateText);
            this.Controls.Add(this.cashTotalText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cashSaleText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cash10Text);
            this.Controls.Add(this.label1);
            this.Name = "Form6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "End of Game Summary";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label cash10Text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label cashSaleText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label cashTotalText;
        private System.Windows.Forms.Label winStateText;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label targetText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label diffText;
    }
}