﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WGP_ICA
{
    public partial class Form6 : Form
    {
        public Form6(CPotluck p, string endGame)
        {
            InitializeComponent();
            int sale = (p.NumBoats * 80) + (p.NumPots * 4);
            cash10Text.Text = "$" + Convert.ToString(p.Cash-sale);
            cashSaleText.Text = "$" + Convert.ToString(sale);
            cashTotalText.Text = "$" + Convert.ToString(p.Cash);
            targetText.Text = "$" + Convert.ToString(p.Target);
            if (p.Cash > p.Target)
                diffText.Text = "$" + Convert.ToString(p.Cash - p.Target);
            else
            {
                diffText.Text = "-$" + Convert.ToString(p.Target - p.Cash);
                diffText.ForeColor = Color.Red;
            }
            winStateText.Text = endGame;

        }
    }
}
