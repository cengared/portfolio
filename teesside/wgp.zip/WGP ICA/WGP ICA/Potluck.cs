﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace WGP_ICA
{
    [Serializable]
    public class CPotluck
    {
        #region CPotluck Fields

        // fields
        private int cash;
        private int target;
        private int day;
        private int numBoats;
        private int numPots;
        private EWeather yesterday;
        private ELocation location;
        private int diceRoll;
        private EWeather today;
        private int earnToday;
        private string errorMessage;

        #endregion

        #region CPotluck Properties

        // properties
        public int Cash
        {
            get { return cash; }
            set { cash = value; }
        }

        public int Target
        {
            get { return target; }
            //set { target = value; }
        }

        public int Day
        {
            get { return day; }
            set { day = value; }
        }

        public int NumBoats
        {
            get { return numBoats; }
            set { numBoats = value; }
        }

        public int NumPots
        {
            get { return numPots; }
            set { numPots = value; }
        }

        public EWeather Yesterday
        {
            get { return yesterday; }
            set { yesterday = value; }
        }

        public ELocation Location
        {
            get { return location; }
            set { location = value; }
        }

        public int DiceRoll
        {
            get { return diceRoll; }
            set { diceRoll = value; }
        }

        public EWeather Today
        {
            get { return today; }
            set { today = value; }
        }

        public int EarnToday
        {
            get { return earnToday; }
            set { earnToday = value; }
        }

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }

        #endregion

        #region CPotluck Methods

        // methods
        public void RollDice()
        {
            Random rnd = new Random();

            diceRoll = rnd.Next(6) + 1;

            switch (diceRoll)
            {
                case 1:
                    today = EWeather.eCalm;
                    break;
                case 2:
                    today = EWeather.eCalm;
                    break;
                case 3:
                    today = EWeather.eCalm;
                    break;
                case 4:
                    today = yesterday;
                    break;
                case 5:
                    today = EWeather.eStorm;
                    break;
                case 6:
                    today = EWeather.eStorm;
                    break;
            }
        }

        public bool Buy(int boats, int pots)
        {
            int cost = (boats * 100) + (pots * 5);
            errorMessage = null;
            if (cost > cash)
            {
                errorMessage = "Cannot complete transaction, not enough cash available.";
                return false;
            }
            else
            {
                if ((numPots + pots) / (numBoats + boats) > 20)
                {
                    errorMessage = "Cannot complete transaction as you are limited to 20 pots per boat.";
                    return false;
                }
                else
                {
                    cash -= cost;
                    numBoats += boats;
                    numPots += pots;
                    return true;
                }
            }
        }

        public bool Sell(int boats, int pots)
        {
            errorMessage = null;
            if (numBoats - boats <= 0)
            {
                errorMessage = "Cannot complete transcation, you need to have at least one boat.";
                return false;
            }
            else if (boats > numBoats || pots > numPots)
            {
                errorMessage = "Cannot complete transaction, not enough equipment available to sell.";
                return false;
            }
            else if ((numPots + pots) / 20 > (numBoats - boats))
            {
                errorMessage = "Cannot complete transaction as must have one boat for every 20 pots." +
                    "\nEither sell more pots or fewer boats";
                return false;
            }
            else
            {
                cash += (boats * 80) + (pots * 4);
                numBoats -= boats;
                numPots -= pots;
                return true;
            }
        }

        public bool EndGame()
        {
            cash += (numBoats * 80) + (numPots * 4);
            if (cash >= target)
                return true;
            else
                return false;
        }

        public void Advance()
        {
            cash += earnToday;
            day++;
            yesterday = today;
            location = ELocation.eNone;
        }

        public void CalculateEarnings()
        {
            earnToday = 0;

            if (location == ELocation.eHarbour)
            {
                if (today == EWeather.eCalm)
                    earnToday = numPots * 2;
                if (today == EWeather.eStorm)
                    earnToday = numPots * 4;
            }

            if (location == ELocation.eSea)
            {
                if (today == EWeather.eCalm)
                    earnToday = numPots * 8;
                if (today == EWeather.eStorm)
                    numPots = 0;
            }
        }

        public void SaveGame(string fn)
        {
            FileStream fs = new FileStream(fn, FileMode.OpenOrCreate);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, this);
            fs.Close();
        }

        public static CPotluck LoadGame(string fn)
        {
            FileStream fs = new FileStream(fn, FileMode.Open, FileAccess.Read);
            BinaryFormatter bf = new BinaryFormatter();
            CPotluck loaded = (CPotluck)bf.Deserialize(fs);
            fs.Close();
            return loaded;
        }

        public string GetLocationText()
        {
            if (location == ELocation.eHarbour)
                return "harbour";
            if (location == ELocation.eSea)
                return "sea";
            if (location == ELocation.eNone)
                return "none";
            else
                return "error";
        }

        public string GetYesterdayText()
        {
            if (yesterday == EWeather.eCalm)
                return "calm";
            if (yesterday == EWeather.eStorm)
                return "storm";
            else
                return "error";
        }
        
        public string GetTodayText()
        {
            if (today == EWeather.eCalm)
                return "calm";
            if (today == EWeather.eStorm)
                return "storm";
            else
                return "error";
        }
        #endregion

        // constructor
        public CPotluck()
        {
            cash = 0;
            target = 1000;
            day = 1;
            numBoats = 1;
            numPots = 10;
            yesterday = EWeather.eCalm;
            location = ELocation.eNone;
            diceRoll = 0;
        }
    }
}
